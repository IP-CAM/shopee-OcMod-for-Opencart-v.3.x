<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End partner_id License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedshopee
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class Cedshopee
{
    private $db;
    private $session;
    private $config;
    private $currency;
    private $request;
    private $weight;
    protected $api_url = '';
    protected $partner_id = '';
    protected $shop_id = '';
    protected $timestamp;

    private static $instance;

    /**
     * @param  object $registry Registry Object
     */
    public static function getInstance($registry)
    {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    /**
     * @param  object $registry Registry Object
     */
    public function __construct($registry)
    {
        $this->db = $registry->get('db');
        $this->session = $registry->get('session');
        $this->config = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->request = $registry->get('request');
        $this->weight = $registry->get('weight');
        $this->openbay = $registry->get('openbay');
        $this->timestamp = time();
    }

    public function _init()
    {
        $this->_api_url = $this->config->get('cedshopee_api_url');
        $this->partner_id = $this->config->get('cedshopee_partner_id');
        $this->shop_id = $this->config->get('cedshopee_shop_id');
        $this->signature = $this->config->get('cedshopee_shop_signature');
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        $flag = false;
        if ($this->config->get('cedshopee_status')) {
            $flag = true;
            $this->_init();
        }
        return $flag;
    }

    /**
     * Post Request
     * $params = ['file' => "", 'data' => "" ]
     * @param string $url
     * @param array $params
     * @return string|array
     */
    public function postRequest($url, $params = array())
    {
        $request = null;
        $response = null;
        $enable = $this->isEnabled();
        if ($enable) {
            try {
                $host = str_replace('/api/v1/', '', $this->config->get('cedshopee_api_url'));
                $host = str_replace('https://', '', $host);
                $url = $this->config->get('cedshopee_api_url') . $url;
                $jsonBody = $this->createJsonBody($params);
                $headers = array(
                    'Accept: application/json',
                    'Content-Type: application/json',
                    'Authorization: '.$this->signature($url, $jsonBody),
                    'Host: '.$host,
                    'Content-Length: '.strlen($jsonBody)
                );
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST,       true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonBody);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_HEADER, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                $servererror = curl_error($ch);
                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $body = substr($response, $header_size);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $this->log('Headers');
                $this->log($headers);
                $this->log('Parameters');
                $this->log($params);
                $this->log('body');
                $this->log($body);
                $this->log('Responses');
                $this->log($response);
                if ($body) {
                    $body = json_decode($body, true);
                }
                if ($httpcode != 200) {
                    return $body;
                }
                if (!empty($servererror)) {
                    $request = curl_getinfo($ch);
                    curl_close($ch);
                    return array('error' => 'server_error', 'msg' => $servererror);
                }
                curl_close($ch);
                if ($body && ($httpcode == 200)) {
                    return $body;
                } else {
                    return '{}';
                }
            } catch (Exception $e) {
                $this->log(
                    "Shopee\\Shopee\\Request\\postRequest() : \n URL: " . $url .
                    "\n Request : \n" . var_export($request, true) .
                    "\n Response : \n " . var_export($body, true) .
                    "\n Errors : \n " . var_export($e->getMessage(), true)
                );
                return array('error' => $httpcode, 'msg' => $body);
            }
        }
    }

    /**
     * Generate an HMAC-SHA256 signature for a HTTP request
     *
     * @param UriInterface $uri
     * @param string $body
     * @return string
     */
    protected function signature($url, $body)
    {
        $data = $url . '|' . $body;
        return hash_hmac('sha256', $data, trim($this->signature));
    }

    protected function createJsonBody(array $data)
    {
        $data = array_merge(array(
            'shopid' => (int)$this->shop_id,
            'partner_id' => (int)$this->partner_id,
            'timestamp' => time(),
        ), $data);
        return json_encode($data);
    }

    public function getSku($product_id = 0)
    {
        if ($product_id) {
            $sku = '';
            $field = 'sku';
            $sql = "SELECT `attribute_id` FROM `" . DB_PREFIX . "cedshopee_product_field_mapping` WHERE `cedshopee_id`='" . $field . "'";
            $mappedField = $query = $this->db->query($sql);
            if ($mappedField->num_rows) {
                $field = $mappedField->row['attribute_id'];
            }
            if ($field && $product_id) {
                $result_product = $this->db->query("SELECT `" . $field . "` FROM `" . DB_PREFIX . "product` where `product_id` = '" . $product_id . "'");
                if ($result_product->num_rows) {
                    return $result_product->row[$field];
                }
            }
            $sql = "SELECT `sku` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id`='" . $product_id . "'";
            $result = $this->db->query($sql);
            if ($result && $result->num_rows && isset($result->row['sku']) && $result->row['sku']) {
                $sku = $result->row['sku'];
            }
            if (strlen(trim($sku)) <= 4) {
                $sql = "SELECT `sku` FROM `" . DB_PREFIX . "product` where `product_id`='" . $product_id . "'";
                $result = $this->db->query($sql);
                if ($result && $result->num_rows && isset($result->row['sku'])) {
                    $sku = $result->row['sku'];
                }
            }
            return $sku;
        }
    }

    public function isCedshopeeInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "cedshopee_install'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function installCedshopee()
    {
        $cedshopee_discount = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_discount` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `discount_name` text COLLATE utf8_unicode_ci NOT NULL,
          `discount_id` int(11) NOT NULL,
          `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          `end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
          `items` longtext NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_discount);
        if ($created)
            $this->log("cedshopee_discount table created", 6, true);

        $cedshopee_uploaded_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_uploaded_products` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `shopee_profile_id` int(11) NOT NULL,
          `shopee_status` text COLLATE utf8_unicode_ci NOT NULL,
          `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shopee_item_id` bigint(20) NOT NULL,
          `logistics` text COLLATE utf8_unicode_ci NOT NULL,
          `wholesale` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_uploaded_products);
        if ($created)
            $this->log("cedshopee_uploaded_product table created", 6, true);

        $cedshopee_attribute = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_attribute` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `attribute_id` bigint(20) NOT NULL,
          `attribute_name` text COLLATE utf8_unicode_ci NOT NULL,
          `is_mandatory` tinyint(1) NOT NULL,
          `attribute_type` text COLLATE utf8_unicode_ci NOT NULL,
          `input_type` text COLLATE utf8_unicode_ci NOT NULL,
          `options` longtext COLLATE utf8_unicode_ci NOT NULL,
          `category_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_attribute);
        if ($created)
            $this->log("cedshopee_attribute table created", 6, true);

        $cedshopee_category = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_category` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `category_id` bigint(11) NOT NULL,
          `category_name` text COLLATE utf8_unicode_ci NOT NULL,
          `parent_id` bigint(20) NOT NULL,
          `has_children` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_category);
        if ($created)
            $this->log("cedshopee_category table created", 6, true);

        $cedshopee_logistics = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_logistics` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `logistic_id` text COLLATE utf8_unicode_ci NOT NULL,
          `logistic_name` text COLLATE utf8_unicode_ci NOT NULL,
          `has_cod` tinyint(1) NOT NULL,
          `enabled` tinyint(1) NOT NULL,
          `fee_type` text COLLATE utf8_unicode_ci NOT NULL,
          `sizes` longtext COLLATE utf8_unicode_ci NOT NULL,
          `weight_limits` longtext COLLATE utf8_unicode_ci NOT NULL,
          `item_max_dimension` longtext COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_logistics);
        if ($created)
            $this->log("cedshopee_logistics table created", 6, true);

        $cedshopee_order = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_order` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `order_place_date` datetime DEFAULT NULL COMMENT 'Order Place Date',
          `opencart_order_id` int(11) DEFAULT NULL COMMENT 'Opencart Order Id',
          `status` text COLLATE utf8_unicode_ci COMMENT 'status',
          `order_data` text COLLATE utf8_unicode_ci COMMENT 'Order Data',
          `shipment_data` text COLLATE utf8_unicode_ci COMMENT 'Shipping Data',
          `shopee_order_id` text COLLATE utf8_unicode_ci COMMENT 'Reference Order Id',
          `shipment_request_data` text COLLATE utf8_unicode_ci COMMENT 'Shipment Data send on shopee',
          `shipment_response_data` text COLLATE utf8_unicode_ci COMMENT 'Shipment Data get from shopee',
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_order);
        if ($created)
            $this->log("cedshopee_order table created", 6, true);

        $cedshopee_order_error = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_order_error` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `shopee_order_id` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Purchase Order Id',
          `merchant_sku` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Reference_Number',
          `reason` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reason',
          `order_data` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Order Data',
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_order_error);
        if ($created)
            $this->log("cedshopee_order_error table created", 6, true);

        $cedshopee_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_products` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `shopee_status` text COLLATE utf8_unicode_ci NOT NULL,
          `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shopee_item_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_products);
        if ($created)
            $this->log("cedshopee_products table created", 6, true);


        $cedshopee_product_variations = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_product_variations` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `variation_sku` text COLLATE utf8_unicode_ci NOT NULL,
          `status` text COLLATE utf8_unicode_ci NOT NULL,
          `is_removed` text COLLATE utf8_unicode_ci NOT NULL,
          `variation_id` int(11) NOT NULL,
          `stock` int(11) NOT NULL,
          `price` float NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_product_variations);
        if ($created)
            $this->log("cedshopee_product_variations table created", 6, true);

        $cedshopee_profile = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_profile` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `title` text COLLATE utf8_unicode_ci NOT NULL,
          `store_category` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shopee_categories` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shopee_category` longtext COLLATE utf8_unicode_ci NOT NULL,
          `profile_attribute_mapping` longtext COLLATE utf8_unicode_ci NOT NULL,
          `status` int(11) NOT NULL,
          `logistics` longtext COLLATE utf8_unicode_ci NOT NULL,
          `wholesale` longtext COLLATE utf8_unicode_ci NOT NULL,
          `default_mapping` text COLLATE utf8_unicode_ci NOT NULL,
          `profile_store` text COLLATE utf8_unicode_ci NOT NULL,
          `product_manufacturer` text COLLATE utf8_unicode_ci NOT NULL,
          `profile_language` int(11) NOT NULL,
          `shopee_category_name` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_profile);
        if ($created)
            $this->log("cedshopee_profile table created", 6, true);

        $cedshopee_profile_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_profile_products` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `shopee_profile_id` int(11) NOT NULL,
          `shopee_status` text COLLATE utf8_unicode_ci NOT NULL,
          `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
          `shopee_item_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_profile_products);
        if ($created)
            $this->log("cedshopee_profile_products table created", 6, true);

        $cedshopee_return = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_return` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `reason` text COLLATE utf8_unicode_ci NOT NULL,
          `text_reason` longtext COLLATE utf8_unicode_ci NOT NULL,
          `returnsn` text COLLATE utf8_unicode_ci NOT NULL,
          `ordersn` text COLLATE utf8_unicode_ci NOT NULL,
          `return_data` longtext COLLATE utf8_unicode_ci NOT NULL,
          `status` text COLLATE utf8_unicode_ci NOT NULL,
          `dispute_request` longtext COLLATE utf8_unicode_ci NOT NULL,
          `dispute_response` longtext COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ;";

        $created = $this->db->query($cedshopee_return);
        if ($created)
            $this->log("cedshopee_return table created", 6, true); 

        $cedshopee_log = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedshopee_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `method` text COLLATE utf8_unicode_ci NOT NULL,
        `message` text COLLATE utf8_unicode_ci NOT NULL,
        `response` text COLLATE utf8_unicode_ci NOT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
      ) ;";  

        $created = $this->db->query($cedshopee_log);
        if ($created)
            $this->log("cedshopee_log table created", 6, true); 
    }

    public function log($data, $force_log = false, $step = 6)
    {
        if ($this->config->get('cedshopee_debug') || $force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('cedshopee.log');
            if (is_array($data))
                $data = json_encode($data);
            if (isset($backtrace[$step]) && isset($backtrace[$step]['class']) && isset($backtrace[$step]['class'])) {
                $log->write('(' . $backtrace[$step]['class'] . '::' . $backtrace[$step]['function'] . ') - ' . $data);
            } else {
                $log->write($data);
            }
        }
    }

    public function getMultliplyNumber($weightClassId)
    {
        $query = $this->db->query("SELECT * FROM `".DB_PREFIX."weight_class_description` WHERE weight_class_id = ".(int)$weightClassId." AND language_id = ".(int)$this->config->get('config_language_id'));
        if ($query->num_rows) {
            if ($query->row['unit'] == 'kg') {
                return '1';
            } elseif ($query->row['unit'] == 'g') {
                return '0.001';
            } elseif ($query->row['unit'] == 'lb') {
                return '0.453592';
            } elseif ($query->row['unit'] == 'oz') {
                return '0.0283495';
            }
        } else {
            return false;
        }
    }

    public function uploadProducts($product_ids)
    {
        $product_ids = array_filter($product_ids);
        $product_ids = array_unique($product_ids);
        $validation_error = array();
        if (!empty($product_ids)) {
            $productToUpload = array();
            $itemCount = 0;
            foreach ($product_ids as $product_id) {
                if (is_numeric($product_id)) {
                    $profile_info = $this->getProfileByProductId($product_id);
                    $product = $this->getProduct($product_id);
                    if ($profile_info && !empty($product)) {

                        $product_info = $this->getCedShopeeMappedProductData($product_id, $profile_info, $product);

                        $category = $this->getCedShopeeCategory($product_id, $profile_info, $product);

                        $price = $this->getCedShopeePrice($product_id, $product);

                        /*if ($_SERVER['REMOTE_ADDR'] == '103.97.184.162') {
                            echo '_FINAL PRICE';
                            print_r($price);die;
                        }*/

                        $stock = $this->getCedShopeeQuantity($product_id, $product);

                        $attributes = $this->getCedShopeeAttribute($product_id, $profile_info, $product);
                        if(!empty($attributes)){
                            $productToUpload['attributes'] =  $attributes;
                        } else {
                            $productToUpload['attributes'] =  array(array('attributes_id' => 8794, 'value' => (string)'No Brand'));
//                            $productToUpload['attributes'] =  array(array('attributes_id' => 19428, 'value' => (string)'No Brand'));
                        }

                        $images = $this->productSecondaryImageURL($product_id, $product);


                        $productToUpload['category_id'] = (int) $category;

                        if(isset( $product_info['name']) &&  $product_info['name'])
                            $productToUpload['name'] = (string) $product_info['name'];
                        else
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Name is required Field';

                        if(isset( $product_info['description']) &&  $product_info['description'])
                            $productToUpload['description'] = (string) (strip_tags(substr(html_entity_decode($product_info['description']),0,2495).'...'));
                        else
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Description is required Field';

                        $productToUpload['price'] = (float) $price;

                        $productToUpload['stock'] =  (int)$stock;

                            if(isset( $product_info['item_sku']) &&  $product_info['item_sku'])
                            $productToUpload['item_sku'] = (string) $product_info['item_sku'];

                            if(isset( $product_info['weight']) &&  $product_info['weight']) {
                            $productToUpload['weight'] = (float) $product_info['weight'];
                            if (isset($product['weight_class_id'])) {
                                $muliplyBy = $this->getMultliplyNumber($product['weight_class_id']);
                                if (!empty($muliplyBy)) {
                                    $productToUpload['weight'] = ((float)$productToUpload['weight'] * $muliplyBy) > 0.1 ? (float)$productToUpload['weight'] * $muliplyBy : 0.2;
                                }
                            }
                        }

                        if(isset( $product_info['package_length']) &&  (int)$product_info['package_length'])
                            $productToUpload['package_length'] = (int) $product_info['package_length'];

                        if(isset( $product_info['package_width']) &&  (int)$product_info['package_width'])
                            $productToUpload['package_width'] = (int) $product_info['package_width'];

                        if(isset( $product_info['package_height']) &&  (int)$product_info['package_height'])
                            $productToUpload['package_height'] =  (int)$product_info['package_height'];

                        if(isset( $product_info['days_to_ship']) &&  (int)$product_info['days_to_ship'])
                            $productToUpload['days_to_ship'] = (int) $product_info['days_to_ship'];

                        if(!empty($images))
                            $productToUpload['images'] = (array) $images;
                        else
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Image is required Field';

                        if(isset( $product_info['days_to_ship']) &&  $product_info['days_to_ship'])
                            $productToUpload['days_to_ship'] = (int) $product_info['days_to_ship'];

                        $logistics = $this->getLogistics($profile_info, $product_id);

                        if(!empty($logistics))
                            $productToUpload['logistics'] =  $logistics;
                        else
                            $validation_error[$itemCount] = 'Product ID '.$product_id.'Logistics is required Field';

                        $wholesales  = $this->getWholesales($profile_info, $product_id, $productToUpload['price']);
                        //print_r($wholesales);die;
                        if(!empty($wholesales))
                            $productToUpload['wholesales'] = (array) array($wholesales);

                        $result = $this->db->query("SELECT shopee_item_id FROM `".DB_PREFIX."cedshopee_uploaded_products` where product_id='".$product_id."'");
                        if($result->num_rows && isset($result->row['shopee_item_id'])) {
                            $productToUpload['item_id'] = (int)$result->row['shopee_item_id'];
                        } else {
                            $productToUpload['item_id'] = 0;
                        }
                        if ($variants = $this->isVariantProduct($product_id, $product_info)) {
                            $productToUpload['variations'] = (array) $variants;
                        }
                        /*if ($_SERVER['REMOTE_ADDR'] == '103.97.184.162') {
                            print_r($productToUpload);die;
                        }*/
                        $valid = $this->validateProduct($productToUpload, $category);

                        if (isset($valid['success']) && $valid['success']) {
                            $itemCount++;
                            if (count($productToUpload) && (count($validation_error) == 0)) {
                                //print_r($productToUpload);die;
                                if(isset($productToUpload['item_id']) && $productToUpload['item_id']) {

                                    unset($productToUpload['images']);
                                    $response = $this->postRequest('item/update', $productToUpload);
                                } else {
                                    $response = $this->postRequest('item/add', $productToUpload);
                                }
                                //print_r($response);
                                if (isset($response['item_id']) && $response['item_id']) {
                                    if (isset($response['msg']) && $response['msg']) {


                                        //$this->db->query("UPDATE `".DB_PREFIX."cedshopee_profile_products` SET shopee_item_id='".$response['item_id']."', shopee_status='".$response['item']['status']."' where product_id='".$product_id."'");
                                        // INSERT INTO
                                        $this->db->query("INSERT INTO `".DB_PREFIX."cedshopee_uploaded_products` SET product_id = ".(int)$product_id.", shopee_item_id = '".$response['item_id']."', shopee_status = '".$response['item']['status']."'");


                                        $variations = $this->postRequest('item/get', array('item_id' => (int)$response['item_id']));

                                        if(isset($variations['item']['variations']) && !empty($variations['item']['variations']))  {
                                            foreach ($variations['item']['variations'] as $variation) {

                                                $name = $variation['name'];
                                                $qty= $variation['stock'];;
                                                $price= $variation['price'];;
                                                $variation_id= $variation['variation_id'];;
                                                $sku= $variation['variation_sku'];;

                                                $product_option_value_query = $this->db->query("SELECT id, variation_id FROM `" . DB_PREFIX . "cedshopee_product_variations` where variation_sku = '".$sku."' AND product_id='".$product_id."'");

                                                if($product_option_value_query && $product_option_value_query->num_rows) {
                                                    $this->db->query("UPDATE `" . DB_PREFIX . "cedshopee_product_variations`  SET variation_id='".(int)$variation_id."', stock='".(int)$qty."',price='".(float)$price."',name='".$name."' where variation_sku = '".$this->db->escape($sku)."' AND product_id='".$product_id."'");
                                                } else {
                                                    $this->db->query("INSERT INTO `" . DB_PREFIX . "cedshopee_product_variations` SET variation_id='".(int)$variation_id."',stock='".(int)$qty."',price='".(float)$price."',name='".$name."',variation_sku = '".$this->db->escape($sku)."',product_id='".$product_id."'");
                                                }
                                            }
                                        }
                                        return array('success' => true, 'message' => $response['msg']);

                                    }

                                } else if (isset($response['error']) && isset($response['msg']) && $response['msg']) {
                                    return array('success' => false, 'message' => $response['msg']);
                                }
                            } else {
                                return array('success' => false, 'message' => $validation_error);
                            }
                        } else {
                            return array('success' => false, 'message' => 'Required Attribute are Missing : -'.$valid['message']);
                        }
                    } else {
                        continue;
                    }
                }
            }
        }
    }

    public function validateProduct($productToUpload, $category){
        if(isset($productToUpload['attributes'])) {
            $required_attribute = array();
            $product_attribute = array();
            $Required_product_attribute = array();
            $result = $this->db->query("SELECT attribute_id,attribute_name FROM `".DB_PREFIX."cedshopee_attribute` where category_id='".$category."' AND is_mandatory='1'");
            if($result && $result->num_rows) {
                foreach ($result->rows as  $row) {
                    $required_attribute[] =  $row['attribute_id'];
                    $Required_product_attribute[$row['attribute_id']] = $row['attribute_name'];
                }
            }

            foreach($productToUpload['attributes'] as $attribute) {
                $product_attribute[] =  $attribute['attributes_id'];
            }
            $product_attribute = array_unique($product_attribute);
            $array_not_found = array_diff($required_attribute,$product_attribute);
            if(!empty($array_not_found)) {
                $name='';
                foreach ($array_not_found as $attribute_id) {
                    if(isset($Required_product_attribute[$attribute_id]))
                        $name .= $Required_product_attribute[$attribute_id];
                }
                return array('success' => false, 'message' =>$name);
            }
        }
        return array('success' => true, 'message' =>$productToUpload);
    }

    public function getLogistics($profile_info, $product_id = null) {
        $logistics = array();
        $fromProductUploadTable = $this->db->query("SELECT * FROM `".DB_PREFIX."cedshopee_uploaded_products` WHERE product_id = ".(int)$product_id);

        if(isset($profile_info['logistics']) && !empty($profile_info['logistics'])) {
            $profile_logistics = json_decode($profile_info['logistics'], true);
            if(!empty($profile_logistics) && isset($profile_logistics['logistics'])){
                foreach ($profile_logistics['logistics'] as $profile_logistic) {
                    $result = $this->db->query("SELECT * FROM `".DB_PREFIX."cedshopee_logistics` where logistic_id='".trim($profile_logistic)."'");
                    if($result && $result->num_rows && $result->row && isset($result->row['fee_type']) && ($result->row['fee_type']='CUSTOM_PRICE')){
                        $logistics[] = array('logistic_id' => (int)$profile_logistic,'enabled' =>  (bool) $result->row['enabled'], 'is_free' =>  (bool) $profile_logistics['is_free'],'shipping_fee' => (float)$profile_logistics['shipping_fee']);
                    } else {
                        $logistics[] = array('logistic_id' => (int)$profile_logistic, 'is_free' =>  (bool) $profile_logistics['is_free'], 'enabled' =>  (bool) $profile_logistics['is_free']);
                    }
                }
            }
        }
        if ($fromProductUploadTable->num_rows) {
            if (isset($fromProductUploadTable->row['logistics']) && !empty($fromProductUploadTable->row['logistics'])) {
                $product_logistics = @json_decode($fromProductUploadTable->row['logistics'], true);
                if (is_array($product_logistics) && !empty($product_logistics)) {
                    foreach ($product_logistics as $product_logistic) {
                        $result = $this->db->query("SELECT * FROM `".DB_PREFIX."cedshopee_logistics` where logistic_id='".trim($profile_logistic)."'");
                        if($result && $result->num_rows && $result->row && isset($result->row['fee_type']) && ($result->row['fee_type']='CUSTOM_PRICE')){
                            $logistics[] = array('logistic_id' => (int)$product_logistic,'enabled' =>  (bool) $result->row['enabled'], 'is_free' =>  (bool) $product_logistic['is_free'],'shipping_fee' => (float)$product_logistic['shipping_fee']);
                        } else {
                            $logistics[] = array('logistic_id' => (int)$product_logistic, 'is_free' =>  (bool) $product_logistic['is_free'], 'enabled' =>  (bool) $product_logistic['is_free']);
                        }
                    }
                }
            }
        }
        return $logistics;
    }

    public function getWholesales($profile_info, $product_id = null, $originalPrice) {
        $wholesales = array();

        $uploadProductTable = $this->db->query("SELECT * FROM `".DB_PREFIX."cedshopee_uploaded_products` WHERE product_id = ".(int)$product_id);


        if(isset($profile_info['wholesale']) && !empty($profile_info['wholesale'])) {
                $profile_wholesale = json_decode($profile_info['wholesale'], true);
            if(!empty($profile_wholesale) && isset($profile_wholesale['wholesale_min'])){
                $wholesales['min'] =(int) $profile_wholesale['wholesale_min'];
            }
            if(!empty($profile_wholesale) && isset($profile_wholesale['wholesale_max'])){
                $wholesales['max'] = (int)$profile_wholesale['wholesale_max'];
            }
            if(!empty($profile_wholesale) && isset($profile_wholesale['wholesale_unit_price'])){
                if (empty($profile_wholesale['wholesale_unit_price'])) {
                    $wholesales['unit_price'] = 0;
                } else {
                    $wholesales['unit_price'] = ($originalPrice - ($originalPrice*(float)$profile_wholesale['wholesale_unit_price'])/100);//(float)$profile_wholesale['wholesale_unit_price'];
                }
            }
        }

        if ($uploadProductTable->num_rows) {
                if (isset($uploadProductTable->row['wholesale']) && !empty($uploadProductTable->row['wholesale'])) {
                $product_wholesale = @json_decode($uploadProductTable->row['wholesale'], true);
                if (isset($product_wholesale) && !empty($product_wholesale)) {
                    $wholesales['min'] = (isset($product_wholesale['wholesale_min']) && !empty($product_wholesale['wholesale_min'])) ? (int)$product_wholesale['wholesale_min'] : 0;
                    $wholesales['max'] = (isset($product_wholesale['wholesale_max']) && !empty($product_wholesale['wholesale_max'])) ? (int)$product_wholesale['wholesale_max'] : 0;
                    $wholesales['unit_price'] = (isset($product_wholesale['wholesale_unit_price']) && !empty($product_wholesale['wholesale_unit_price'])) ? (($originalPrice*(float)$profile_wholesale['wholesale_unit_price'])/100) : 0;
                }
            }
        }
        return array_filter($wholesales);
    }

    public function getProduct($product_id)
    {
        $product = false;
        $query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'product_id=" . (int)$product_id . "' AND language_id = '".$this->config->get('config_language_id')."') AS keyword FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '" . (int)$product_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
        if ($query->num_rows)
            $product = $query->row;
        return $product;
    }

    public function isVariantProduct($product_id, $product)
    {
        $attirbute_combination = array();
        $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "' AND o.type IN ('select','radio','checkbox')");
        if ($product_option_query && $product_option_query->num_rows) {
            foreach ($product_option_query->rows as $option) {
                $product_option_value_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `".DB_PREFIX."option_value_description` ovd ON (pov.option_value_id=ovd.option_value_id) WHERE pov.product_id = '" . (int)$product_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
                if($product_option_value_query && $product_option_value_query->num_rows) {
                    foreach ($product_option_value_query->rows as $option_value) {
                        if(isset($option_value['product_option_value_id']) && isset($option_value['product_option_id']) && isset($option_value['option_id']) && isset($option_value['option_value_id']))
                        {
                            $attirbute_combination[$option_value['product_option_id']][$option_value['product_option_value_id']] = $option_value['product_option_value_id'];

                            $variant_sku = $product_id.'-'.$option_value['product_option_id'].'-'.$option_value['option_id'].'-'.$option_value['product_option_value_id'];
                            $variant_qty = $option_value['quantity'];
                            $price = $option_value['price'];
                            $price_prefix = $option_value['price_prefix'];
                            $variant_price = $this->calculateValueByPrefix($product['price'], $price, $price_prefix);
                            $name = $option_value['name'];
                            $attirbute_combination_variant[$option_value['product_option_value_id']] = array(
                                'name' => (string)$name,
                                'stock' => (int)$variant_qty,
                                'price' => (float)$variant_price,
                                'variation_sku' => (string)$variant_sku,
                            );
                        }
                    }
                }
            }
        }
        $variations = array();
        if(count(array_values($attirbute_combination))>1)
            $attirbute_combination_options = $this->combinations(array_values($attirbute_combination));
        else
            $attirbute_combination_options = array($attirbute_combination_variant);

        if(!empty($attirbute_combination_options) && (count($attirbute_combination_options)>1)) {

            foreach ($attirbute_combination_options as $attirbute_combination_option) {
                $name = '';
                $qty = array();
                $price = array();
                $sku = '';
                foreach ($attirbute_combination_option as $attirbute_combination_opt) {

                    if(isset($attirbute_combination_variant[$attirbute_combination_opt]) && $attirbute_combination_variant[$attirbute_combination_opt]){
                        $attirbute_combination_variant[$attirbute_combination_opt];
                        $name .= $attirbute_combination_variant[$attirbute_combination_opt]['name'].' ';
                        $qty[] = $attirbute_combination_variant[$attirbute_combination_opt]['stock'];
                        $price[] = $attirbute_combination_variant[$attirbute_combination_opt]['price'];
                        $sku .= $attirbute_combination_variant[$attirbute_combination_opt]['variation_sku'].'sku'.$attirbute_combination_opt;
                    }

                }
                $product_option_value_query = $this->db->query("SELECT id, variation_id FROM `" . DB_PREFIX . "cedshopee_product_variations` where variation_sku = '".$sku."' AND product_id='".$product_id."'");
                if( $product_option_value_query  &&  $product_option_value_query ->num_rows && isset($product_option_value_query ->row['variation_id']) && $product_option_value_query ->row['variation_id']) {
                    $variations[] = array(
                        'name' => (string)trim($name),
                        'stock' => (int)min($qty),
                        'price' => (float)$product['price']+max($price),
                        'variation_sku' => (string)$sku,
                        'variation_id' => (int) $product_option_value_query ->row['variation_id'],
                    );
                } else {
                    $variations[] = array(
                        'name' => (string)trim($name),
                        'stock' => (int)min($qty),
                        'price' => (float)$product['price']+max($price),
                        'variation_sku' => (string)$sku,
                    );
                }

            }
        } else {
            if(isset($attirbute_combination_options[0])) {
                foreach ($attirbute_combination_options[0] as $attirbute_combination_option) {

                    $sku = $attirbute_combination_option['variation_sku'];
                    $product_option_value_query = $this->db->query("SELECT id, variation_id FROM `" . DB_PREFIX . "cedshopee_product_variations` where variation_sku = '".$sku."' AND product_id='".$product_id."'");
                    if( $product_option_value_query  &&  $product_option_value_query ->num_rows && isset($product_option_value_query ->row['variation_id']) && $product_option_value_query ->row['variation_id']) {
                        $variations[] = array(
                            'name' => (string)trim($attirbute_combination_option['name']),
                            'stock' => (int)$attirbute_combination_option['stock'],
                            'price' => (float)$product['price']+$attirbute_combination_option['price'],
                            'variation_sku' => (string)$attirbute_combination_option['variation_sku'],
                            'variation_id' => (int) $product_option_value_query ->row['variation_id'],
                        );
                    } else {
                        $variations[] = array(
                            'name' => (string)trim($attirbute_combination_option['name']),
                            'stock' => (int)$product['stock'] + $attirbute_combination_option['stock'],
                            'price' => (float)$product['price']+$attirbute_combination_option['price'],
                            'variation_sku' => (string)$attirbute_combination_option['variation_sku'],
                        );
                    }

                }
            }
        }
        return $variations;
    }

    public function calculateValueByPrefix($original_value, $value, $prefix) {
        switch ($prefix) {
            case '+' :
                return (float)$original_value + (float)$value;
                break;
            case '-' :
                return (float)$original_value - (float)$value;
                break;
            default :
                return $original_value;
                break;
        }
    }

    public function processVariantsProducts($product_id, $itemCount, $productToUpload, $variants, $cedshopee_parent_cat_id, $cedshopee_child_cat_id)
    {
        $variants_data = array();
        $parent_data = $productToUpload["MPItemFeed"]["MPItem"][$itemCount];
        if (is_array($variants) && count($variants)) {
            $variantId = $this->randomstring(20);
            foreach ($variants as $key => $variant) {
                if (isset($variant['option_combination']) && isset($variant['unique_choice']) && isset($variant['unique_value']) && isset($variant['merchant_sku']) && $variant['option_combination'] && $variant['unique_choice'] && $variant['unique_value'] && $variant['merchant_sku']) {
                    if (isset($parent_data['sku']) && $parent_data['sku']) {
                        $parent_data['sku'] = $variant['merchant_sku'];
                        $parent_data['productIdentifiers']['productIdentifier'] = array('productIdType' => $variant['unique_choice'], 'productId' => $variant['unique_value']);

                        if (isset($variant['option_combination']) && strlen($variant['option_combination']) > 0) {
                            $variantAttributeName = array();
                            $combination = json_decode($variant['option_combination'], true);
                            $options_value_array = array();
                            $options_array = array();
                            foreach ($combination as $key => $value) {

                                $result_product = $this->db->query("SELECT `cedshopee_id` FROM `" . DB_PREFIX . "cedshopee_option_mapping` where `wchild_category` = '" . $cedshopee_child_cat_id . "' AND `option_id` = '" . $key . "' AND `wparent_category` = '" . $cedshopee_parent_cat_id . "'");
                                if ($result_product && $result_product->num_rows) {
                                    $options_array[$key] = $result_product->row['cedshopee_id'];
                                    $variantAttributeName[] = $result_product->row['cedshopee_id'];
                                }

                                $result_product = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "option_value_description` pod on (pov.option_value_id = pod.option_value_id) WHERE `product_id` = '" . $product_id . "' AND pov.option_id = '" . $key . "' AND pov.option_value_id = '" . $value . "'");
                                if ($result_product && $result_product->num_rows) {
                                    $options_value_array[$key] = $result_product->row['name'];
                                }
                            }
                            $variant_names = array();
                            if (is_array($options_array) && count($options_array)) {
                                foreach ($options_array as $key => $value) {
                                    $variant_names[$value] = $options_value_array[$key];
                                }
                            }
                            foreach ($variant_names as $key => $value) {
                                $parent_data[$key] = $value;
                            }
                            $parent_data['variantGroupId'] = $variantId;
                            $parent_data['variantAttributeNames'] = array('variantAttributeName' => $variantAttributeName);
                        }
                    }
                }
                $variants_data[$itemCount] = $parent_data;
                $itemCount++;
            }
        }
        return $variants_data;
    }

    public function getCedShopeeMappedProductData($product_id, $profile_info, $product)
    {
        if ($product_id && isset($profile_info['default_mapping']) && $profile_info['default_mapping']) {
            $default_mapping = json_decode($profile_info['default_mapping'], true);
            if (!empty($default_mapping)) {
                $mapped_data = array();
                foreach ($default_mapping as $key => $value) {
                    if (isset($product[$value]) && $product[$value]) {
                        $mapped_data[$key] = $product[$value];
                    } else if ($key == 'days_to_ship') {
                        $mapped_data[$key] = $value;
                    }
                }
                return $mapped_data;
            }
        } else {
            return false;
        }
    }

    public function getCedShopeePrice($product_id, $product = array())
    {
        $specialPrice = 0;
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$product_id . "' ORDER BY priority, price");
        $product_specials = array();
        if ($query && $query->num_rows) {
            $product_specials = $query->rows;
        }

        foreach ($product_specials as $product_special) {
            if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                $specialPrice = $product_special['price'];

                break;
            }
        }

        $product_price = 0;
        if (isset($product['price'])) {
            $product_price = $product['price'];
        } else {
            $query_price = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$product_id . "'");

            if ($query_price && $query_price->num_rows) {
                $product_price = $query_price->row['price'];
            }
        }

        $price = (float)$product_price;

        if (($specialPrice > 0) && ($specialPrice < $price)) {
            $price = $specialPrice;
        }
        /*if ($_SERVER['REMOTE_ADDR'] == '103.97.184.162') {
            print_r($price);
            echo '<pre>';
        }*/

        $cedshopee_price_choice = trim($this->config->get(
            'cedshopee_price_choice'));

        /*if ($_SERVER['REMOTE_ADDR'] == '103.97.184.162') {
            var_dump($cedshopee_price_choice);
        }*/

        switch ($cedshopee_price_choice) {
            case '2':
                $fixedIncement = trim($this->config->get('cedshopee_variable_price'));
                $price = $price + $fixedIncement;

                break;

            case '3':
                $fixedIncement = trim($this->config->get('cedshopee_variable_price'));
                $price = $price - $fixedIncement;

                break;


            case '4':
                $percentPrice = trim($this->config->get('cedshopee_variable_price'));
                $price = (float)($price + (($price / 100) * $percentPrice));

                break;

            case '5':

                $percentPrice = trim($this->config->get('cedshopee_variable_price'));
                $price = (float)($price - (($price / 100) * $percentPrice));

                break;

            case '6':
                $result = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id`='" . $product_id . "'");
                if ($result && $result->num_rows && isset($result->row['price']))
                    $price = (isset($result->row['price']) && $result->row['price'] != 0) ? $result->row['price'] : $price;

                break;

            default:
                return (float)$price;
                break;
        }
        return (float)$price;
    }

    public function getCedShopeeQuantity($product_id, $product = array())
    {
        $quantity = 0;
        if(isset($product['stock'])){
            $quantity = $product['stock'];
        } else if($product_id) {
            $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` where `product_id` = '" . $product_id . "'");
            if ($result->num_rows) {
                $quantity = $result->row['quantity'];
            } else {
                $quantity = 0;
            }
        }
        return $quantity;

    }

    public function getCedShopeeCategory($product_id, $profile_info, $product)
    {
        if ($product_id) {
            $shopee_category = false;
            if (isset($profile_info['shopee_category']) && $profile_info['shopee_category']) {
                $shopee_category = $profile_info['shopee_category'];
            }
            return $shopee_category;
        } else {
            return false;
        }
    }

    public function getCedShopeeAttribute($product_id, $profile_info, $product)
    {
        if ($product_id && isset($profile_info['profile_attribute_mapping']) && $profile_info['profile_attribute_mapping']) {
            $profile_attribute_mappings = json_decode($profile_info['profile_attribute_mapping'], true);
            $attribute_shopees = array();
            if ($profile_attribute_mappings) {
                foreach ($profile_attribute_mappings as $profile_attribute_mapping)
                {
                    $attribute_shopee = array();
                    if(isset($profile_attribute_mapping['input_type']) && (($profile_attribute_mapping['input_type']=='COMBO_BOX') || ($profile_attribute_mapping['input_type']=='DROP_DOWN'))){
                        $attribute_shopee = $this->getProductOptions($product_id, $profile_attribute_mapping);
                    } else if(isset($profile_attribute_mapping['input_type']) && ($profile_attribute_mapping['input_type']=='TEXT_FILED')) {
                        $attribute_shopee = $this->getProductAttributes($product_id, $profile_attribute_mapping);
                    }
                    $attribute_shopees = array_merge($attribute_shopees, $attribute_shopee);
                }

                $attribute_shopees = array_filter($attribute_shopees);
                return $attribute_shopees;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function productSecondaryImageURL($product_id, $product)
    {
        if ($product_id) {
            $base_url = HTTP_CATALOG;
            if (strpos($base_url, 'amituofofo') !== false) {
                $base_url = str_replace('amituofofo/', '', $base_url);
            }

            $productImages = array();
            $additionalAssets = array();
            $query = $this->db->query("SELECT `image` FROM " . DB_PREFIX . "product_image WHERE product_id = '" . (int)$product_id . "' ORDER BY sort_order ASC");
            if ($query && $query->num_rows) {
                $productImages = $query->rows;
            }

            if (isset($product['image'])) {
                $productImages[] = array('image' => (string) $product['image']);
            }

            if (!empty($productImages)) {
                foreach ($productImages as $product_image) {
                    if (is_file(DIR_IMAGE . $product_image['image'])) {
                        $additionalAssets[] = array('url' => (string) $base_url.'image/'.$product_image['image']);
                        if (count($additionalAssets) == 9) {
                            break;
                        }
                    }
                }
            }

            return $additionalAssets;
        }
    }

    /*public function productSecondaryImageURL($product_id, $product)
    {
        if ($product_id) {
            $base_url = HTTPS_SERVER;
            if (strpos($base_url, 'admin') !== false) {
                $base_url = str_replace('admin/', '', $base_url);
            }

            $productImages = array();
            $additionalAssets = array();
            $query = $this->db->query("SELECT `image` FROM " . DB_PREFIX . "product_image WHERE product_id = '" . (int)$product_id . "' ORDER BY sort_order ASC");
            if ($query && $query->num_rows) {
                $productImages = $query->rows;
            }

            if (isset($product['image'])) {
                $productImages[] = array('image' => (string)'https://cedcommerce.com/skin/frontend/cedcom/default/images/ced_new_footer/Awardwinner.png');// $product['image']
            }

            if (!empty($productImages)) {
                foreach ($productImages as $product_image) {
                    if (is_file(DIR_IMAGE . $product_image['image'])) {
                        $additionalAssets[] = array('url' => (string)'https://cedcommerce.com/skin/frontend/cedcom/default/images/ced_new_footer/Awardwinner.png');
                        if (count($additionalAssets) == 9) {
                            break;
                        }
                    }
                }
            }
            return $additionalAssets;
        }
    }*/

    public function getProductAttributes($product_id, $mapped_attributes)
    {
        $product_attribute_data = array();

        if(isset($mapped_attributes['store_attribute']) && $mapped_attributes['shopee_attribute'] && isset($mapped_attributes['shopee_attribute']) && $mapped_attributes['shopee_attribute']) {

            $store_attribute = $mapped_attributes['store_attribute'];

            $shopee_attribute = $mapped_attributes['shopee_attribute'];

            $product_attribute_query = $this->db->query("SELECT attribute_id FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$store_attribute . "'");

            if($product_attribute_query && $product_attribute_query->num_rows) {
                foreach ($mapped_attributes['options'][$shopee_attribute] as $option_values) {
                    $product_attribute_data[] = array('attributes_id' => (int)$shopee_attribute, 'value' => $option_values['shopee_options']);
                }
            }
        }

        return $product_attribute_data;
    }

    public function getProductOptions($product_id, $maped_options) 
    {
        $product_option_data = array();
        if(isset($maped_options['store_attribute']) && $maped_options['shopee_attribute'] && isset($maped_options['shopee_attribute']) && $maped_options['shopee_attribute']) {
            $store_attribute = $maped_options['store_attribute'];
            $shopee_attribute = $maped_options['shopee_attribute'];
            $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND  o.option_id = '".(int) $store_attribute."' AND  od.language_id = '" . (int)$this->config->get('config_language_id') . "'");
            if ($product_option_query->num_rows && isset($maped_options['options'][$shopee_attribute]))   {
                foreach ($maped_options['options'][$shopee_attribute] as $option_values) {
                    $product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_option_id = '" . (int)$product_option_query->row['product_option_id'] . "' AND option_value_id  = '" . (int)$option_values['store_options'] . "'");
                    if($product_option_value_query->num_rows && isset($option_values['shopee_options']) && $option_values['shopee_options']) {
                        $product_option_data[] = array('attributes_id' =>(int) $shopee_attribute, 'value' => $option_values['shopee_options']);
                    }
                }
            }
        }
        return $product_option_data;
    }

    public function fetchOrder($url, $params)
    {
        $response = $this->postRequest($url, $params);
        try {
            if (!empty($response)) {
                if (!isset($response['error'])) {
                    if (is_array($response) && !empty($response)) {
                        $order_ids = array();
                        if (is_array($response) && isset($response['orders']) && count($response['orders'])) {

                            $totalOrderFetched = count($response['orders']);
                            $response['orders'] = array_chunk($response['orders'], '5');
                            foreach ($response['orders'] as $key => $orders) {
                                $order_to_fetch = array();
                                foreach ($orders as $key => $order) {
                                    $already_exist = $this->isPurchaseOrderIdExist($order['ordersn']);
                                    if ($already_exist) {
                                        continue;
                                    } else {
                                        $order_to_fetch[] = $order['ordersn'];
                                    }
                                }
                                $orders_data = $this->fetchOrderDetails($order_to_fetch);

                                foreach ($orders_data['orders'] as $key => $order_data) {

                                    if (isset($order_data['ordersn']) && $order_data['ordersn']) {
                                        $ordersn = $order_data['ordersn'];
                                        $orderData = $this->prepareOrderData($order_data);

                                        $this->log(json_encode($orderData), '6', true);
                                        $order_ids[] = $this->CreateOrder($orderData);
                                    }
                                }
                                if (count($order_ids) == $totalOrderFetched) {
                                    return array('success' => true, 'message' => $order_ids);
                                } else if (count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                                    return array('success' => true, 'message' => $order_ids, 'sub_message' => 'Please see Rejected List too.');
                                } else if (count($order_ids) == 0) {
                                    return array('success' => true, 'message' => 'No new Order Found.');
                                } else {
                                    return array('success' => false, 'message' => 'Order Send to Rejected List.');
                                }
                            }
                        }
                    } else {
                        return array('success' => false, 'message' => 'No New Order From Shopee.');
                    }
                } else {
                    return array('success' => false, 'message' => $response['msg']);
                }
            } else {
                return array('success' => false, 'message' => $this->language->get('error_module'));
            }
        } catch (Exception $e) {
            $this->log('Order Error:  ' . var_export($response, true));
            return false;
        }
    }

    public function acknowledgeOrder($shopee_order_id, $url = 'v3/orders')
    {
        $response = $this->WPostRequest($url . '/' . $shopee_order_id . '/acknowledge'
        );
        try {
            if (isset($response['success']) && $response['success']) {
                $response = $response['response'];
            } else {
                return $response;
            }
            $response = json_decode($response, true);
            if (isset($response['error'])) {
                return array('success' => false, 'message' => $response['error']);
            }
            $this->updateOrderStatus($shopee_order_id, 'acknowledged');
            return $response;
        } catch (Exception $e) {
            $this->log('acknowledgeOrder' . var_export($response, true));
            return false;
        }

    }

    public function updateOrderStatus($shopee_order_id, $status = 'created')
    {
        $result = $this->db->query("SELECT `opencart_order_id` FROM `" . DB_PREFIX . "cedshopee_order` where `shopee_order_id` = '" . (int)$shopee_order_id . "'");
        $order_id = 0;
        if ($result && $result->num_rows) {
            $order_id = $result->row['opencart_order_id'];
        }
        $order_status_id = $this->getOrderStatusId($status);
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', date_added = NOW()");
        $this->db->query("UPDATE " . DB_PREFIX . "order SET `order_status_id` = '" . (int)$order_status_id . "' WHERE `order_id` = '" . (int)$order_id . "'");
    }

    public function shipOrder($ship_data = null)
    {

        $trackingNumber = '';
        if (isset($ship_data['tracking_number'])) {
            $trackingNumber = $ship_data['tracking_number'];
        }

        $ordersn = '';
        if (isset($ship_data['ordersn'])) {
            $ordersn = $ship_data['ordersn'];
        }
        if($trackingNumber && $ordersn){

            try {
                $params = array('info_list' => array(array('tracking_number' => $trackingNumber, 'ordersn' =>$ordersn)));
                $response = $this->postRequest('logistics/tracking_number/set_mass',
                    $params);
                if (isset($response['result']) && $response['result']) {
                    if (isset($response['result']['success_count']) && $response['result']['success_count']) {
                        $this->updateOrderStatus($ordersn, 'shipped');
                        return array('success' => true, 'response' => json_encode($response));
                    } else {
                        return array('success' => false, 'message' => $response['result']['error_codes']);
                    }
                }
            } catch (Exception $e) {
                $this->log('Response: ' . var_export($response, true));
                return array('success' => false, 'message' => 'Response: ' . var_export($response, true));
            }
        }
    }

    public function cancelOrder($params)
    {
        $response = $this->postRequest('orders/cancel', $params);
        try {
            if (!isset($response['error']) && $response['error']) {
                if (isset($response['response']) && $response['response']) {
                    return array('success' => true, 'response' => $response['msg']);
                } else if(isset($response['msg'])) {
                    return array('success' => false, 'message' => $response['msg']);
                }
            }else if(isset($response['msg'])) {
                return array('success' => false, 'message' => $response['msg']);
            }
        } catch (Exception $e) {
            $this->log('cancelOrder: ' . var_export($response, true));
            return false;
        }
    }

    public function getProductBySKU($sku, $q, $product_title, $cedshopee_price, $itemDiscountedCost, $shopee_order_id, $worder_data, $orderLine)
    {
        $product = array();
        //checking merchant sku in variants
        $sql = "SELECT `product_id`,`option_combination` FROM `" . DB_PREFIX . "cedshopee_product_variations` WHERE `merchant_sku`='" . $sku . "'";
        // for variation
        $query = $this->db->query($sql);
        //var_dump($query->num_rows);
        //var_dump($query->num_rows);die('tet');
        if (0) {
            $option_combination = isset($query->row['option_combination']) ? $query->row['option_combination'] : '';
            $product['product_id'] = isset($query->row['product_id']) ? $query->row['product_id'] : '';
            $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `" . DB_PREFIX . "product` WHERE `product_id`='" . $product['product_id'] . "'";
            $query = $this->db->query($sql);
            if (strlen($product_title) == '0') {
                $sql_name = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id`='" . $product['product_id'] . "' and `language_id`='" . $this->config->get('config_language_id') . "'";
                $query_name = $this->db->query($sql_name);
                if ($query_name->num_rows)
                    $product_title = $query_name->row['name'];
            }
            if ($query->num_rows) {
                $status = $query->row['status'];
                $minimum = $query->row['minimum'];
                $quant = $query->row['quantity'];
                $model = $query->row['model'];
                $price = $query->row['price'];
                if ($status) {
                    if ($quant >= $q) {
                        $product['quantity'] = $q;
                        $product['model'] = $model;
                        $product['subtract'] = $q;
                        $product['price'] = $cedshopee_price;
                        $product['total'] = ($cedshopee_price) ? ($q * $cedshopee_price) : $q * $price;
                        $product['tax'] = $this->config->get('cedshopee_tax');
                        $product['reward'] = 0;
                        $product['name'] = $product_title;
                        $product['option'] = json_decode($option_combination, true);
                        $product['download'] = array();
                        return $product;
                    } else {
                        $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "REQUESTED QUANTITY FOR PRODUCT ID " . $product['product_id'] . " IS NOT AVAILABLE", $orderLine);

                        return array();
                    }
                } else {
                    $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "PRODUCT STATUS IS DISABLED WITH ID " . $product['product_id'] . "", $orderLine);
                    return array();
                }


            } else {
                $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "PRODUCT ID" . $product['product_id'] . " DOES NOT EXIST", $orderLine);
                return array();
            }

        } else {
            // checking merchant sku in products
            $mappedSkuField = 'sku';
            /*      $sql = "SELECT `attribute_id` FROM `" . DB_PREFIX . "cedshopee_product_field_mapping` WHERE `cedshopee_id`='".$mappedSkuField."'";
      $mappedField=$query = $this->db->query($sql);
      if($mappedField->num_rows){
        $mappedSkuField=$mappedField->row['attribute_id'];
      }*/
            $sql = "SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE " . $mappedSkuField . "='" . $sku . "'";
            $productdata = $query = $this->db->query($sql);
            $product['product_id'] = '';
            if ($productdata->num_rows) {
                $product['product_id'] = $productdata->row['product_id'];
            }
            if ($product['product_id']) {
                $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `" . DB_PREFIX . "product` WHERE `product_id`='" . $product['product_id'] . "'";
                $query = $this->db->query($sql);
                if (strlen($product_title) == '0') {
                    $sql_name = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id`='" . $product['product_id'] . "' and `language_id`='" . $this->config->get('config_language_id') . "'";
                    $query_name = $this->db->query($sql_name);
                    if ($query_name->num_rows)
                        $product_title = $query_name->row['name'];
                }
                if ($query->num_rows) {

                    $status = $query->row['status'];
                    $minimum = $query->row['minimum'];
                    $quant = $query->row['quantity'];
                    $model = $query->row['model'];
                    $price = $query->row['price'];
                    if ($status) {

                        if (($quant >= $q) || $this->config->get('cedshopee_force_order_fetch')) {

                            $product['quantity'] = $q;
                            $product['model'] = $model;
                            $product['subtract'] = $q;
                            $product['price'] = ($itemDiscountedCost) ? $itemDiscountedCost : $cedshopee_price;
                            $product['tax'] = $this->config->get('cedshopee_tax');
                            $product['total'] = ($product['price']) ? ($q * $product['price']) + $product['tax'] : $q * $price + $product['tax'];
                            $product['reward'] = 0;
                            $product['name'] = $product_title;
                            $product['option'] = array();
                            $product['download'] = array();
                            return $product;
                        } else {
                            $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "REQUESTED QUANTITY FOR PRODUCT ID " . $product['product_id'] . " IS NOT AVAILABLE", $orderLine);

                            return array();
                        }
                    } else {
                        $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "PRODUCT STATUS IS DISABLED WITH ID " . $product['product_id'] . "", $orderLine);
                        return array();
                    }


                } else {
                    $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "PRODUCT ID" . $product['product_id'] . " DOES NOT EXIST", $orderLine);
                    return array();
                }
            } else {
                $this->orderErrorInformation($sku, $shopee_order_id, $worder_data, "MERCHANT SKU DOES NOT EXIST", $orderLine);
                return array();
            }
        }
    }

    public function fetchOrderDetails($order_ids)
    {
        $order_data = array();
        if (count($order_ids)) {
            $url = 'orders/detail';
            $this->log($url);
            $params = array('ordersn_list' => $order_ids);
            $this->log($params);
            $order_data = $this->postRequest($url, $params);
        }
        /*    $order_data = '{
    "orders": [
    {
    "tracking_no": "758IEPV0L617T931",
    "update_time": 1471254360,
    "estimated_shipping_fee": "",
    "actual_shipping_cost": "",
    "shipping_carrier": "NINJAVAN",
    "payment_method": "PAY_COD",
    "country": "SG",
    "escrow_amount": "372.00",
    "days_to_ship": 3,
    "currency": "SGD",
    "create_time": 1467887672,
    "cod": true,
    "ordersn": "1607071834879801",
    "order_status": "ORDER_ESCROW_VERIFIED",
    "message_to_seller": "",
    "recipient_address": {
    "town": "",
    "city": "",
    "name": "very  long name Long long long long long long long long long lon",
    "district": "",
    "country": "SG",
    "zipcode": "266321",
    "full_address": "39 CORONATION ROAD WEST, #13 , SG, 266321",
    "phone": "6587773905",
    "state": ""
    },
    "items": [
    {
    "item_sku": "100",
    "variation_sku": "10",
    "item_name": "several models test",
    "variation_quantity_purchased": 1,
    "variation_name": "{% checkout %}",
    "variation_discounted_price": "100.00",
    "variation_original_price": "100.00"
    },
    {
    "item_sku": "100",
    "variation_sku": "10",
    "item_name": "sellerpromotionwithmodel",
    "variation_quantity_purchased": 1,
    "variation_name": "a",
    "variation_discounted_price": "0.10",
    "variation_original_price": "0.10"
    },
    {
    "item_sku": "100",
    "variation_sku": "10",
    "item_name": "sellerpromotionwithmodel",
    "variation_quantity_purchased": 1,
    "variation_name": "b",
    "variation_discounted_price": "0.10",
    "variation_original_price": "0.50"
    },
    {
    "item_sku": "100",
    "variation_sku": "10",
    "item_name": "veryloggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggfffgffffffffffffffffffffffffff",
    "variation_quantity_purchased": 1,
    "variation_name": "",
    "variation_discounted_price": "100.00",
    "variation_original_price": "100.00"
    }
    ],
    "total_amount": "372.00"
    }
    ]
    }';*/
        $order_data = json_decode($order_data, true);
        return $order_data;
    }

    public function CreateOrder($data)
    {
        if (is_array($data) && count($data)) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "',store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "',payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', order_status_id = '" . (int)$this->getOrderStatusId('cedshopee Processing') . "', affiliate_id  = '" . (int)$data['affiliate_id'] . "', language_id = '" . (int)$this->config->get('config_language_id') . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', date_added = NOW(), date_modified = NOW()");
            $order_id = $this->db->getLastId();
            if ($order_id && isset($data['sorder_id']) && $data['sorder_id']) {

                $sql = "UPDATE `" . DB_PREFIX . "cedshopee_order` SET `opencart_order_id` = '" . (int)$order_id . "' where `id`='" . (int)$data['sorder_id'] . "'";
                $this->db->query($sql);
            }

            // Products
            foreach ($data['products'] as $product) {
                $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

                $order_product_id = $this->db->getLastId();

                // arun
                // for options mapping in product

                if (isset($product['option']) && count($product['option']) > 0) {
                    foreach ($product['option'] as $option_id => $option_value) {
                        $sql = "SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM " . DB_PREFIX . "product_option_value pov LEFT JOIN " . DB_PREFIX . "product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN " . DB_PREFIX . "option o ON (pov.option_id =o.option_id) LEFT JOIN " . DB_PREFIX . "option_description od ON (pov.option_id =od.option_id) JOIN " . DB_PREFIX . "option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id) where pov.option_value_id =" . (int)$option_value . " and pov.product_id=" . (int)$product['product_id'];
                        $options_data = $this->db->query($sql);
                        if ($options_data->num_rows) {
                            $option = $options_data->row;
                            $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                        }
                    }
                }
            }

            // Get the total
            $total = 0;

            if (isset($data['totals'])) {
                foreach ($data['totals'] as $order_total) {
                    $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($order_total['code']) . "', title = '" . $this->db->escape($order_total['title']) . "', text = '" . $this->db->escape($order_total['text']) . "',`value` = '" . (float)$order_total['value'] . "', sort_order = '" . (int)$order_total['sort_order'] . "'");
                    if ($order_total['code'] == 'total') {
                        $total += $order_total['value'];
                    }
                }
            }
            // Update order total

            $this->db->query("UPDATE `" . DB_PREFIX . "order` SET total = '" . (float)$total . "' WHERE order_id = '" . (int)$order_id . "'");

            $this->addOrderHistory($order_id, $this->getOrderStatusId("Shopee Processing"));
            return $order_id;
        } else {
            return 0;
        }
    }

    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "language WHERE language_id = '" . (int)$order_query->row['language_id'] . "'");

            if ($query && $query->num_rows) {
                $language_info = $query->row;

                if ($language_info) {
                    $language_code = $language_info['code'];
                    $language_filename = $language_info['filename'];
                    $language_directory = $language_info['directory'];
                } else {
                    $language_code = '';
                    $language_filename = '';
                    $language_directory = '';
                }
            }


            return array(
                'order_id' => $order_query->row['order_id'],
                'invoice_no' => $order_query->row['invoice_no'],
                'invoice_prefix' => $order_query->row['invoice_prefix'],
                'store_id' => $order_query->row['store_id'],
                'store_name' => $order_query->row['store_name'],
                'store_url' => $order_query->row['store_url'],
                'customer_id' => $order_query->row['customer_id'],
                'customer' => $order_query->row['customer'],
                'customer_group_id' => $order_query->row['customer_group_id'],
                'firstname' => $order_query->row['firstname'],
                'lastname' => $order_query->row['lastname'],
                'telephone' => $order_query->row['telephone'],
                'fax' => $order_query->row['fax'],
                'email' => $order_query->row['email'],
                'payment_firstname' => $order_query->row['payment_firstname'],
                'payment_lastname' => $order_query->row['payment_lastname'],
                'payment_company' => $order_query->row['payment_company'],
                'payment_company_id' => $order_query->row['payment_company_id'],
                'payment_tax_id' => $order_query->row['payment_tax_id'],
                'payment_address_1' => $order_query->row['payment_address_1'],
                'payment_address_2' => $order_query->row['payment_address_2'],
                'payment_postcode' => $order_query->row['payment_postcode'],
                'payment_city' => $order_query->row['payment_city'],
                'payment_zone_id' => $order_query->row['payment_zone_id'],
                'payment_zone' => $order_query->row['payment_zone'],
                'payment_zone_code' => $payment_zone_code,
                'payment_country_id' => $order_query->row['payment_country_id'],
                'payment_country' => $order_query->row['payment_country'],
                'payment_iso_code_2' => $payment_iso_code_2,
                'payment_iso_code_3' => $payment_iso_code_3,
                'payment_address_format' => $order_query->row['payment_address_format'],
                'payment_method' => $order_query->row['payment_method'],
                'payment_code' => $order_query->row['payment_code'],
                'shipping_firstname' => $order_query->row['shipping_firstname'],
                'shipping_lastname' => $order_query->row['shipping_lastname'],
                'shipping_company' => $order_query->row['shipping_company'],
                'shipping_address_1' => $order_query->row['shipping_address_1'],
                'shipping_address_2' => $order_query->row['shipping_address_2'],
                'shipping_postcode' => $order_query->row['shipping_postcode'],
                'shipping_city' => $order_query->row['shipping_city'],
                'shipping_zone_id' => $order_query->row['shipping_zone_id'],
                'shipping_zone' => $order_query->row['shipping_zone'],
                'shipping_zone_code' => $shipping_zone_code,
                'shipping_country_id' => $order_query->row['shipping_country_id'],
                'shipping_country' => $order_query->row['shipping_country'],
                'shipping_iso_code_2' => $shipping_iso_code_2,
                'shipping_iso_code_3' => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_method' => $order_query->row['shipping_method'],
                'shipping_code' => $order_query->row['shipping_code'],
                'comment' => $order_query->row['comment'],
                'total' => $order_query->row['total'],
                'reward' => $reward,
                'order_status_id' => $order_query->row['order_status_id'],
                'commission' => $order_query->row['commission'],
                'language_id' => $order_query->row['language_id'],
                'language_code' => $language_code,
                'language_filename' => $language_filename,
                'language_directory' => $language_directory,
                'currency_id' => $order_query->row['currency_id'],
                'currency_code' => $order_query->row['currency_code'],
                'currency_value' => $order_query->row['currency_value'],
                'ip' => $order_query->row['ip'],
                'forwarded_ip' => $order_query->row['forwarded_ip'],
                'partner_id_agent' => $order_query->row['partner_id_agent'],
                'accept_language' => $order_query->row['accept_language'],
                'date_added' => $order_query->row['date_added'],
                'date_modified' => $order_query->row['date_modified']
            );
        } else {
            return false;
        }
    }

    public function getOrderStatusId($name)
    {
        $sql = "SELECT `order_status_id` FROM `" . DB_PREFIX . "order_status` WHERE `name`='" . $name . "'";
        $query = $this->db->query($sql);
        if ($query && $query->num_rows)
            return $query->row['order_status_id'];
        else
            return '1';
    }

    public function addOrderHistory($order_id, $order_status_id, $comment = '', $notify = true)
    {

        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data = array();
        $data['order_status_id'] = (int)$order_status_id;
        $data['order_id'] = (int)$order_id;
        $data['comment'] = 'A Shopee Order Imported Successfully';
        $data['notify'] = (int)$notify;
        // Stock subtraction
        $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

        $ids_products = array();
        foreach ($order_product_query->rows as $order_product) {
            $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$order_product['product_id'] . "'");
            $this->log(json_encode($result->rows), 6, true);
            if (!$this->config->get('cedshopee_use_shipstation')) {
                $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");

                $this->log('Product Id And QTY.' . $order_product['product_id'] . ' - ' . $order_product['quantity'], 6, true);
                $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$order_product['order_product_id'] . "'");

                foreach ($order_option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
                if (isset($order_product['product_id']) && (int)$order_product['product_id'])
                    $ids_products[] = array('product_id' => (int)$order_product['product_id']);
            }

        }
        $this->log('Ids to Update.' . json_encode($ids_products), 6, true);
        if (!$this->config->get('cedshopee_use_shipstation'))
            $this->updateInvenetry($ids_products);

        $this->openbay->orderNew((int)$order_id);
        $order_info = $this->getOrder($order_id);

        if ($order_info) {

            // Update the DB with the new statuses
            $this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '" . (int)$order_status_id . "', date_modified = NOW() WHERE order_id = '" . (int)$order_id . "'");

            $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");


            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                $language = new Language($order_info['language_directory']);
                $language->load($order_info['language_filename']);
                $language->load('mail/order');

                $subject = sprintf($language->get('text_subject'), $order_info['store_name'], $order_id);

                $message = $language->get('text_order') . ' ' . $order_id . "\n";
                $message .= $language->get('text_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n\n";

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$data['order_status_id'] . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $message .= $language->get('text_order_status') . "\n";
                    $message .= $order_status_query->row['name'] . "\n\n";
                }

                if ($order_info['customer_id']) {
                    $message .= $language->get('text_link') . "\n";
                    $message .= html_entity_decode($order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id, ENT_QUOTES, 'UTF-8') . "\n\n";
                }

                if ($data['comment']) {
                    $message .= $language->get('text_comment') . "\n\n";
                    $message .= strip_tags(html_entity_decode($data['comment'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                }

                $message .= $language->get('text_footer');

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->hostname = $this->config->get('config_smtp_host');
                $mail->partner_idname = $this->config->get('config_smtp_partner_idname');
                $mail->shop_idword = $this->config->get('config_smtp_shop_idword');
                $mail->port = $this->config->get('config_smtp_port');
                $mail->timeout = $this->config->get('config_smtp_timeout');
                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender($order_info['store_name']);
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                $mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
                $mail->send();


            }
        }
    }

    public function updateInvenetry($product_ids_update)
    {
        $product_ids = array();
        if (!is_array($product_ids_update)) {
            $product_ids[] = array('product_id' => $product_ids_update);
        } else if (is_array($product_ids_update) && count($product_ids_update)) {
            $product_ids = $product_ids_update;
        }
        if (is_array($product_ids) && count($product_ids)) {

            foreach ($product_ids as $key => $product) {

                $product_id = isset($product['product_id']) ? $product['product_id'] : '0';
                $variants = $this->getVariantProducts($product_id);
                $quantity = 0;
                $sku = $this->getSku($product_id);
                $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` where `product_id` = '" . $product_id . "'");
                if ($result->num_rows) {
                    $quantity = $result->row['quantity'];
                }
                $product_qantity_array = array();
                if (is_array($variants) && count($variants)) {

                    foreach ($variants as $key => $value) {

                        $sku = $value['merchant_sku'];
                        if (isset($value['option_combination']) && count($value['option_combination']) > 0) {
                            $combination = json_decode($value['option_combination'], true);
                            foreach ($combination as $key => $value) {
                                $result = $this->db->query("SELECT `product_option_id`,`option_value_id`,`quantity`,`price`,`price_prefix` FROM `" . DB_PREFIX . "product_option_value` where `product_id` = '" . $product_id . "' AND `option_id` = '" . $key . "' AND `option_value_id` = '" . $value . "'");

                                if ($result->num_rows) {
                                    $options_array[] = $result->row;
                                }
                            }
                        }

                        $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id` = '" . $product_id . "'");
                        if ($result->num_rows) {
                            $quantity = $result->row['quantity'];
                        }
                        $optionsArray = array();
                        if (count($options_array) > 0) {

                            foreach ($options_array as $key => $value) {
                                $quantity_temp = $quantity;
                                $optionsArray[$sku] = array('attribute_id' => (int)$value['product_option_id'], 'attribute_value' => $value['option_value_id']);
                                $product_qantity_array[$sku] = $value['quantity'];
                            }
                        }
                    }
                    $quantity = $product_qantity_array;
                } else {
                    if ($sku)
                        $quantity = array($sku => $this->getcedshopeeQuantity($product_id));
                }
                if (count($quantity)) {
                    $fulfillmentLagTime = $this->config->get('cedshopee_fulfillmentLagTime');
                    foreach ($quantity as $key => $value) {

                        $quantity_request = '<?xml version="1.0" encoding="UTF-8"?>
                  <wm:inventory xmlns:wm="http://cedshopee.com/">
                     <wm:sku>' . $key . '</wm:sku>
                     <wm:quantity>
                        <wm:unit>EACH</wm:unit>
                        <wm:amount>' . $value . '</wm:amount>
                     </wm:quantity>
                     <wm:fulfillmentLagTime>' . $fulfillmentLagTime . '</wm:fulfillmentLagTime>
                  </wm:inventory>';
                    }
                }
                $this->log("Inventry Update ON order Request Log:", 6, true);
                $this->log($quantity_request, 6, true);
                $result = $this->WPutRequest('v2/inventory?sku=' . $sku, $quantity_request);
                $this->log("Inventry Update ON order Response Log:", 6, true);
                $this->log(json_encode($result), 6, true);
            }
        }
    }

    public function orderErrorInformation($sku, $ordersn, $worder_data, $errormessage, $orderLine)
    {
        $sql_check_already_exists = "SELECT * FROM `" . DB_PREFIX . "cedshopee_order_error` WHERE `merchant_sku`='" . $sku . "' AND `shopee_order_id`='" . $ordersn . "'";
        $query_check_already_exists = $this->db->query($sql_check_already_exists);
        if (!$query_check_already_exists->num_rows) {
            $sql_delete = "DELETE  FROM `" . DB_PREFIX . "cedshopee_order_error` WHERE `merchant_sku`='" . $sku . "'";
            $this->db->query($sql_delete);
            $sql_insert = "INSERT INTO `" . DB_PREFIX . "cedshopee_order_error` (`merchant_sku`,`shopee_order_id`,`order_data`,`reason`)VALUES('" . $this->db->escape($sku) . "','" . $ordersn . "','" . $this->db->escape(json_encode($worder_data)) . "','" . $errormessage . "')";
            $result = $this->db->query($sql_insert);
            if ($result) {
                if ($this->config->get('cedshopee_auto_order')) {
                    $this->cancelOrder($ordersn, $orderLine, 'v3/vorders');
                }
            }
        }
    }

    public function getShipmentById($order_id)
    {
        $query = $this->db->query("SELECT `shipment_request_data` FROM `" . DB_PREFIX . "cedshopee_order` WHERE opencart_order_id='" . $order_id . "'");
        if ($query->num_rows) {
            return json_decode($query->row['shipment_request_data'], true);
        }
    }

    public function prepareOrderData($data = array())
    {
        if ($data && isset($data['ordersn'])) {
            $opencart_order_id = 0;
            $shopee_order_id = $data['ordersn'];
            $shipment = $data['recipient_address'];
            $orderDate = $data['create_time'];
            if ($orderDate)
                $orderDate = date("Y-m-d", $orderDate);
            $status = 'Created';
            if (!$this->isPurchaseOrderIdExist($data['ordersn'])) {
                $sql = "INSERT INTO `" . DB_PREFIX . "cedshopee_order` (`id`, `opencart_order_id`,`order_place_date`,`order_data`, `status`, `shopee_order_id`, `shipment_data`) VALUES (NULL, '" . $opencart_order_id . "', '" . $this->db->escape($orderDate) . "', '" . $this->db->escape(json_encode($data)) . "', '" . $status . "', '" . $shopee_order_id . "', '" . $this->db->escape(json_encode($shipment)) . "');";

                $result = $this->db->query($sql);
                $sorder_id = $this->db->getLastId();
                if ($result) {
                    return $this->formatOrderData($data, $sorder_id);
                }
            }
        }
    }

    public function isPurchaseOrderIdExist($shopee_order_id = 0)
    {
        $isExist = false;
        if ($shopee_order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "cedshopee_order` where `shopee_order_id` = '" . $shopee_order_id . "'";
            $result = $this->db->query($sql);
            if ($result && $result->num_rows) {
                $isExist = true;
            }
        }
        return $isExist;
    }

    public function formatOrderData($data, $sorder_id)
    {

        $order_data = array();
        $order_data['sorder_id'] = $sorder_id;
        $order_data['invoice_prefix'] = $this->config->get('config_invoice_prefix');

        $order_data['store_id'] = $this->config->get('config_store_id');

        $order_data['store_name'] = $this->config->get('config_name');

        $base_url = HTTPS_SERVER;

        if (strpos($base_url, 'admin') !== false) {
            $base_url = str_replace('admin/', '', $base_url);
        }

        $order_data['store_url'] = $base_url;

        $order_data['customer_id'] = '';

        $order_data['customer_group_id'] = $this->config->get('config_customer_group_id');

        $firstname = '';

        $lastname = '';

        $email = '';

        $telephone = '';

        if (isset($data['recipient_address'])) {

            if (isset($data['recipient_address']['name'])) {

                $name = $data['recipient_address']['name'];

                $name = explode(' ', $name);

                $length = count($name);

                if ($length % 2 == 0) {

                    $length = $length / 2;

                } else {

                    $length = ($length + 1) / 2;

                }
            }
            $name = array_chunk($name, $length);

            if (isset($name['0'])) {

                $firstname = implode(' ', $name['0']);

            }

            if (isset($name['1'])) {

                $lastname = implode(' ', $name['1']);

            }

            $email = $this->config->get('cedshopee_order_email');

            if (isset($data['recipient_address']['phone'])) {
                $telephone = $data['recipient_address']['phone'];
            }
        }

        $order_data['firstname'] = $firstname;

        $order_data['lastname'] = $lastname;

        $order_data['email'] = $email;

        $order_data['telephone'] = $telephone;

        $order_data['fax'] = '';

        $order_data['custom_field'] = array();

        $order_data['payment_firstname'] = $firstname;

        $order_data['payment_lastname'] = $lastname;

        $order_data['payment_company'] = '';

        $order_data['payment_address_1'] = isset($data['recipient_address']['full_address']) ? $data['recipient_address']['full_address'] : '';

        $order_data['payment_address_2'] = '';

        $order_data['payment_city'] = isset($data['recipient_address']['city']) ? $data['recipient_address']['city'] : '';

        $order_data['payment_postcode'] = isset($data['recipient_address']['zipcode']) ? $data['recipient_address']['zipcode'] : '';

        $state = isset($data['recipient_address']['state']) ? $data['recipient_address']['state'] : '';

        $country = isset($data['recipient_address']['country']) ? $data['recipient_address']['country'] : '';

        $getLocalizationDeatails = $this->getLocalizationDeatails($state, $country);


        $order_data['payment_zone'] = $getLocalizationDeatails['name'];

        $order_data['payment_zone_id'] = $getLocalizationDeatails['zone_id'];

        $order_data['payment_country'] = $getLocalizationDeatails['country_name'];

        $order_data['payment_country_id'] = $getLocalizationDeatails['country_id'];

        $order_data['payment_address_format'] = '';

        $order_data['payment_custom_field'] = array();

        $order_data['payment_method'] = 'cedshopeePayment';

        $order_data['payment_code'] = 'cedshopeePayment';

        $order_data['shipping_firstname'] = $firstname;

        $order_data['shipping_lastname'] = $lastname;

        $order_data['shipping_company'] = '';

        $order_data['shipping_address_1'] = isset($data['recipient_address']['full_address']) ? $data['recipient_address']['full_address'] : '';

        $order_data['shipping_address_2'] = '';

        $order_data['shipping_city'] = isset($data['recipient_address']['city']) ? $data['recipient_address']['city'] : '';

        $order_data['shipping_postcode'] = isset($data['recipient_address']['postalCode']) ? $data['recipient_address']['postalCode'] : '';

        $getLocalizationDeatails = $this->getLocalizationDeatails($state, $country);

        $order_data['shipping_zone'] = $getLocalizationDeatails['name'];

        $order_data['shipping_zone_id'] = $getLocalizationDeatails['zone_id'];

        $order_data['shipping_country'] = $getLocalizationDeatails['country_name'];

        $order_data['shipping_country_id'] = $getLocalizationDeatails['country_id'];;

        $order_data['shipping_address_format'] = '';

        $order_data['shipping_custom_field'] = array();

        $order_data['shipping_method'] = isset($data['shipping_carrier']) ? $data['shipping_carrier'] : '';

        $order_data['shipping_code'] = isset($data['shipping_carrier']) ? $data['shipping_carrier'] : '';


        // for products
        $shippingCost = 0;

        if (isset($data['items']) && count($data['items'])) {

            foreach ($data['items'] as $orderLine => $item) {

                $sku = isset($item['item_sku']) ? $item['item_sku'] : '';
                if (!strlen($sku)) {
                    continue;
                }

                $product_title = $item['item_name'];

                $qty = isset($item['variation_quantity_purchased']) ? $item['variation_quantity_purchased'] : '0';


                $itemCost = isset($item['variation_original_price']) ? $item['variation_original_price'] : '0';

                $itemDiscountedCost = isset($item['variation_discounted_price']) ? $item['variation_discounted_price'] : '0';

                $product = $this->getProductBySKU($sku, $qty, $product_title, $itemCost, $itemDiscountedCost, $data['ordersn'], $data, $orderLine);
                if (is_array($product) && count($product))
                    $order_data['products'][] = $product;
                else
                    continue;
            }
        }


        $sub_total = 0;
        $tax = 0;
        if (isset($order_data['products']) && count($order_data['products']) > 0) {
            foreach ($order_data['products'] as $key => $value) {
                $sub_total = $sub_total + (floatval($value['total']));
                $tax = $tax + (floatval($value['tax']));
            }


            $order_data['comment'] = $data['message_to_seller'];

            $order_data['total'] = (float)$data['total_amount'];

            $order_data['affiliate_id'] = '0';

            $order_data['commission'] = '0';

            $order_data['marketing_id'] = '0';

            $order_data['tracking'] = '';

            $order_data['language_id'] = $this->config->get('config_language_id');

            if (isset($this->session->data['currency']) && $this->session->data['currency']) {
                $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);

                $order_data['currency_code'] = $this->session->data['currency'];

                $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
            } else {

                $order_data['currency_id'] = $this->currency->getId($this->config->get('config_currency'));

                $order_data['currency_code'] = $this->config->get('config_currency');

                $order_data['currency_value'] = $this->currency->getValue($this->config->get('config_currency'));
            }
            $order_data['vouchers'] = array();

            $order_data['totals'][] = array(
                'code' => 'shipping',
                'title' => 'cedshopee Shipping',
                'text' => $this->currency->format((float)$shippingCost),
                'value' => (float)$shippingCost,
                'sort_order' => $this->config->get('shipping_sort_order')
            );
            $order_data['totals'][] = array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'text' => $this->currency->format($sub_total),
                'value' => $sub_total,
                'sort_order' => $this->config->get('sub_total_sort_order')
            );
            $order_data['totals'][] = array(
                'code' => 'tax',
                'title' => 'Tax',
                'text' => $this->currency->format($tax),
                'value' => $tax,
                'sort_order' => $this->config->get('tax_sort_order')
            );
            $order_data['totals'][] = array(
                'code' => 'total',
                'title' => 'Total',
                'text' => $this->currency->format(max(0, $order_data['total'])),
                'value' => max(0, $order_data['total']),
                'sort_order' => $this->config->get('total_sort_order')
            );

            $order_data['ip'] = $this->request->server['REMOTE_ADDR'];

            if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {

                $order_data['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];

            } elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {

                $order_data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];

            } else {

                $order_data['forwarded_ip'] = '';

            }

            if (isset($this->request->server['HTTP_partner_id_AGENT'])) {

                $order_data['partner_id_agent'] = $this->request->server['HTTP_partner_id_AGENT'];

            } else {

                $order_data['partner_id_agent'] = '';

            }

            if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {

                $order_data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];

            } else {

                $order_data['accept_language'] = '';
            }

            if (!empty($this->request->server['HTTP_CLIENT_IP'])) {

                $order_data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];

            } else {

                $order_data['forwarded_ip'] = '';
            }

            if (isset($this->request->server['HTTP_partner_id_AGENT'])) {

                $order_data['partner_id_agent'] = $this->request->server['HTTP_partner_id_AGENT'];

            } else {

                $order_data['partner_id_agent'] = '';
            }

            if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {

                $order_data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];

            } else {
                $order_data['accept_language'] = '';
            }
            return $order_data;
        } else {
            return array();
        }
    }

    public function updateProductPriceOncedshopee($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }

        if (count($product_ids) == 0) {
            $cedshopee_map_cat_all = $this->config->get('cedshopee_map_cat_all');

            if (is_array($cedshopee_map_cat_all) && isset($cedshopee_map_cat_all['children_category']) && isset($cedshopee_map_cat_all['parent_wcat']) && $cedshopee_map_cat_all['children_category'] && $cedshopee_map_cat_all['parent_wcat']) {
                $query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product`");
                if ($query && $query->num_rows) {
                    foreach ($query->rows as $key => $value) {
                        if (isset($value['product_id']) && $value['product_id']) {
                            $ids[] = $value['product_id'];
                        }
                    }
                }
            } else {
                $query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "cedshopee_category_mapping`");
                $ids = array();
                if ($query && $query->num_rows) {
                    foreach ($query->rows as $key => $value) {
                        if (isset($value['category_id']) && $value['category_id']) {
                            $query = $this->db->query("SELECT `product_id` FROM " . DB_PREFIX . "product_to_category WHERE  `category_id` = '" . (int)$value['category_id'] . "'");
                            if ($query && $query->num_rows) {
                                foreach ($query->rows as $key => $value) {
                                    if (isset($value['product_id']) && $value['product_id']) {
                                        $ids[] = $value['product_id'];
                                    }
                                }
                            }
                        }
                    }
                }
            }

            $product_ids = $ids;
        }
        if (is_array($product_ids) && count($product_ids)) {
            $product_idss = array_chunk($product_ids, 9900);
            foreach ($product_idss as $key => $product_ids) {
                $product_price_array = array();
                foreach ($product_ids as $key => $product_id) {
                    $variants = $this->getVariantProducts($product_id);
                    $product_price = 0;
                    $sku = '';
                    $sku = $this->getSku($product_id);
                    $result = $this->db->query("SELECT `price`,`sku` FROM `" . DB_PREFIX . "product` where `product_id` = '" . $product_id . "'");
                    if ($result->num_rows) {
                        $product_price = $result->row['price'];

                    }
                    if (is_array($variants) && count($variants)) {

                        foreach ($variants as $key => $value) {
                            $currentPriceArray = array();
                            $sku = $value['merchant_sku'];
                            if (isset($value['option_combination']) && count($value['option_combination']) > 0) {
                                $combination = json_decode($value['option_combination'], true);
                                foreach ($combination as $key => $value) {
                                    $result = $this->db->query("SELECT `product_option_id`,`option_value_id`,`quantity`,`price`,`price_prefix` FROM `" . DB_PREFIX . "product_option_value` where `product_id` = '" . $product_id . "' AND `option_id` = '" . $key . "' AND `option_value_id` = '" . $value . "'");

                                    if ($result->num_rows) {
                                        $options_array[] = $result->row;
                                    }
                                }
                            }

                            $result = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id` = '" . $product_id . "'");
                            if ($result->num_rows) {
                                $product_price = $result->row['price'];
                            }
                            $optionsArray = array();
                            if (count($options_array) > 0) {

                                foreach ($options_array as $key => $value) {
                                    $product_price_temp = $product_price;
                                    $optionsArray[] = array('attribute_id' => (int)$value['product_option_id'], 'attribute_value' => $value['option_value_id']);
                                    if ($value['price_prefix'] == '+') {
                                        $product_price_temp = $product_price_temp + $value['price'];
                                    } else {
                                        $product_price_temp = $product_price_temp - $value['price'];
                                    }


                                    $specialPrice = 0;
                                    $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_special` WHERE `product_id` = '" . (int)$product_id . "' ORDER BY priority, price");
                                    $product_specials = array();
                                    if ($query && $query->num_rows) {
                                        $product_specials = $query->rows;
                                    }

                                    foreach ($product_specials as $product_special) {
                                        if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                                            $specialPrice = $product_special['price'];

                                            break;
                                        }
                                    }

                                    $price = (float)$product_price_temp;

                                    if ($specialPrice == 0) {
                                        $specialPrice = $price;
                                    }

                                    $cedshopee_price_choice = trim($this->config->get(
                                        'cedshopee_price_choice'));

                                    switch ($cedshopee_price_choice) {
                                        case '2':
                                            $fixedIncement = trim($this->config->get('cedshopee_variable_price'));
                                            $price = $price + $fixedIncement;
                                            $specialPrice = $specialPrice + $fixedIncement;
                                            break;

                                        case '3':
                                            $fixedIncement = trim($this->config->get('cedshopee_variable_price'));
                                            $price = $price - $fixedIncement;
                                            $specialPrice = $specialPrice + $fixedIncement;
                                            break;


                                        case '4':
                                            $percentPrice = trim($this->config->get('cedshopee_variable_price'));
                                            $price = (float)($price + (($price / 100) * $percentPrice));
                                            $specialPrice = (float)($specialPrice + (($specialPrice / 100) * $percentPrice));
                                            break;

                                        case '5':

                                            $percentPrice = trim($this->config->get('cedshopee_variable_price'));
                                            $price = (float)($price - (($price / 100) * $percentPrice));
                                            $specialPrice = (float)($specialPrice - (($specialPrice / 100) * $percentPrice));
                                            break;

                                        case '6':
                                            $result = $this->db->query("SELECT `price` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id`='" . $product_id . "'");
                                            if ($result && $result->num_rows && isset($result->row['price']))
                                                $price = (isset($result->row['price']) && $result->row['price'] != 0) ? $result->row['price'] : $price;
                                            $specialPrice = $price;
                                            break;

                                        default:
                                            $price;
                                            $specialPrice;
                                    }

                                    $final_price = $price;
                                    $final_sprice = $specialPrice;
                                    $product_price_array[$sku] = array('price' => $final_price, 'specialPrice' => $final_sprice);
                                    $price = 0;
                                    $specialPrice = 0;
                                }
                            }
                        }
                    } else {
                        $price = $this->getcedshopeePrice($product_id);
                        $product_price_array[$sku] = $price;
                    }
                }
                $timeStamp = (string)$this->getMilliseconds();
                $priceArray = array(
                    'PriceFeed' => array(
                        '@xmlns' => "http://cedshopee.com/",
                        'PriceHeader' => array(
                            'version' => '1.5',
                        ),
                    ),
                );

                $currency = $this->config->get('config_currency');
                if (is_array($product_price_array) && count($product_price_array)) {
                    foreach ($product_price_array as $key => $product_prices) {
                        $priceArray['PriceFeed']['Price'][] = array(

                            'itemIdentifier' => array(
                                'sku' => $key
                            ),
                            'pricingList' => array(
                                'pricing' => array(
                                    'currentPrice' => array(
                                        'value' => array(

                                            '@currency' => $currency,
                                            '@amount' => $product_prices['specialPrice']


                                        )
                                    ),
                                    'currentPriceType' => 'BASE',
                                    'comparisonPrice' => array(
                                        'value' => array(

                                            '@currency' => $currency,
                                            '@amount' => $product_prices['price']

                                        )
                                    ),
                                )
                            )

                        );
                    }
                }
                $price = $this->feedRequest($priceArray, 'price');
            }
        }
    }

    public function getVariantProducts($product_id)
    {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedshopee_product_variations` where `product_id`='" . $product_id . "'");
        if ($query->num_rows) {
            return $query->rows;
        } else {
            return false;
        }
    }

    public function UpdateProductQtyOncedshopee($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if (count($product_ids) == 0) {
            $cedshopee_map_cat_all = $this->config->get('cedshopee_map_cat_all');

            if (is_array($cedshopee_map_cat_all) && isset($cedshopee_map_cat_all['children_category']) && isset($cedshopee_map_cat_all['parent_wcat']) && $cedshopee_map_cat_all['children_category'] && $cedshopee_map_cat_all['parent_wcat']) {
                $query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product`");
                if ($query && $query->num_rows) {
                    foreach ($query->rows as $key => $value) {
                        if (isset($value['product_id']) && $value['product_id']) {
                            $ids[] = $value['product_id'];
                        }
                    }
                }
            } else {
                $query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "cedshopee_category_mapping`");
                $ids = array();
                if ($query && $query->num_rows) {
                    foreach ($query->rows as $key => $value) {
                        if (isset($value['category_id']) && $value['category_id']) {
                            $query = $this->db->query("SELECT `product_id` FROM " . DB_PREFIX . "product_to_category WHERE  `category_id` = '" . (int)$value['category_id'] . "'");
                            if ($query && $query->num_rows) {
                                foreach ($query->rows as $key => $value) {
                                    if (isset($value['product_id']) && $value['product_id']) {
                                        $ids[] = $value['product_id'];
                                    }
                                }
                            }
                        }
                    }
                }
            }

            $product_ids = $ids;
        }
        if (is_array($product_ids) && count($product_ids)) {
            $product_idss = array_chunk($product_ids, 9900);
            foreach ($product_idss as $key => $product_ids) {
                $inventoryArray = array();
                if (is_array($product_ids) && count($product_ids)) {
                    $product_qantity_array = array();
                    foreach ($product_ids as $key => $product_id) {
                        $variants = $this->getVariantProducts($product_id);
                        $quantity = 0;
                        $sku = '';
                        $sku = $this->getSku($product_id);
                        $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "product` where `product_id` = '" . $product_id . "'");
                        if ($result->num_rows) {
                            $quantity = $result->row['quantity'];
                        }
                        if (is_array($variants) && count($variants)) {

                            foreach ($variants as $key => $value) {
                                $currentPriceArray = array();
                                $sku = $value['merchant_sku'];
                                if (isset($value['option_combination']) && count($value['option_combination']) > 0) {
                                    $combination = json_decode($value['option_combination'], true);
                                    foreach ($combination as $key => $value) {
                                        $result = $this->db->query("SELECT `product_option_id`,`option_value_id`,`quantity`,`price`,`price_prefix` FROM `" . DB_PREFIX . "product_option_value` where `product_id` = '" . $product_id . "' AND `option_id` = '" . $key . "' AND `option_value_id` = '" . $value . "'");

                                        if ($result->num_rows) {
                                            $options_array[] = $result->row;
                                        }
                                    }
                                }

                                $result = $this->db->query("SELECT `quantity` FROM `" . DB_PREFIX . "cedshopee_product` where `product_id` = '" . $product_id . "'");
                                if ($result->num_rows) {
                                    $quantity = $result->row['quantity'];
                                }
                                $optionsArray = array();
                                if (count($options_array) > 0) {

                                    foreach ($options_array as $key => $value) {
                                        $quantity_temp = $quantity;
                                        $optionsArray[$sku] = array('attribute_id' => (int)$value['product_option_id'], 'attribute_value' => $value['option_value_id']);
                                        $product_qantity_array[$sku] = $value['quantity'];
                                    }
                                }
                            }
                        } else {
                            $quantity = $this->getcedshopeeQuantity($product_id);
                            $product_qantity_array[$sku] = $quantity;
                        }
                    }
                    $inventoryArray = array(
                        'InventoryFeed' => array(
                            '@xmlns' => "http://cedshopee.com/",
                            'InventoryHeader' => array(
                                'version' => '1.4',
                            )
                        )
                    );
                    if (is_array($product_qantity_array) && count($product_qantity_array)) {

                        $fulfillmentLagTime = $this->config->get('cedshopee_fulfillmentLagTime');
                        foreach ($product_qantity_array as $key => $product_qantity) {
                            $inventoryArray['InventoryFeed']['inventory'][] = array(
                                'sku' => $key,
                                'quantity' => array(
                                    'unit' => 'EACH',
                                    'amount' => (string)$product_qantity,
                                ),
                                'fulfillmentLagTime' => $fulfillmentLagTime,
                            );
                        }
                    }

                }
                if (count($inventoryArray)) {
                    $inventry = $this->feedRequest($inventoryArray, 'inventry');
                }
            }
        }
    }

    public function getLocalizationDeatails($Statecode, $countryCode)
    {
        $query = $this->db->query("SELECT `country_id`,`name` FROM `" . DB_PREFIX . "country` WHERE `iso_code_3` LIKE '" . $countryCode . "'");
        if ($query->num_rows) {
            $country_id = 0;
            $country_name = '';
            if (isset($query->row['country_id']) && $query->row['country_id']) {
                $country_id = $query->row['country_id'];
                $country_name = $query->row['name'];
            }
            if ($country_id) {
                $query = $this->db->query("SELECT `zone_id`,`name` FROM " . DB_PREFIX . "zone WHERE country_id='" . $country_id . "' AND code='" . $Statecode . "'");
                if ($query->num_rows) {
                    if (isset($query->row['zone_id']) && isset($query->row['name'])) {
                        return array(
                            'country_id' => $country_id,
                            'zone_id' => $query->row['zone_id'],
                            'name' => $query->row['name'],
                            'country_name' => $country_name
                        );
                    };
                } else {
                    return array(
                        'country_id' => '',
                        'zone_id' => '',
                        'name' => '',
                        'country_name' => ''
                    );
                }
            } else {
                return array(
                    'country_id' => '',
                    'zone_id' => '',
                    'name' => '',
                    'country_name' => ''
                );
            }
        } else {
            return array(
                'country_id' => '',
                'zone_id' => '',
                'name' => '',
                'country_name' => ''
            );
        }
    }

    public function getRejectedOrderJson($id)
    {
        $sql = "SELECT `order_data` FROM `" . DB_PREFIX . "cedshopee_order_error` WHERE `id`='" . $id . "'";
        $query = $this->db->query($sql);
        if ($query->num_rows)
            return $query->row['order_data'];
    }

    public function getProfileByProductId($product_id)
    {
        if ($product_id) {
            $result = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedshopee_profile` cp LEFT JOIN `" . DB_PREFIX . "cedshopee_profile_products` cpp on (cp.id = cpp.shopee_profile_id) where cpp.product_id='" . $product_id . "'");
            if ($result && $result->num_rows) {
                return $result->row;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function getShopeeItem($shopee_item_id) {
        $url = 'item/get';
        $this->log($url);
        $params = array('item_id' => $shopee_item_id);
        $this->log($params);
        $item_data = $this->postRequest($url, $params);
        return $item_data;
    }

    public function fetchReturn($url, $params)
    {
        $response = $this->postRequest($url, $params);
        if(isset($response['returns']) && !empty($response['returns'])){
            return array('success' => true, 'response' => $response['returns']);
        } else if(isset($response['error']) && isset($response['msg'])){
            return array('success' => false, 'message' => $response['msg']);
        } else {
            return array('success' => false, 'message' => 'No Return From shopee.');
        }
    }

    public function combinations($arrays, $i = 0) {
        if (!isset($arrays[$i])) {
            return array();
        }
        if ($i == count($arrays) - 1) {
            return $arrays[$i];
        }
        $tmp = $this->combinations($arrays, $i + 1);

        $result = array();
        foreach ($arrays[$i] as $v) {
            foreach ($tmp as $t) {
                $result[] = is_array($t) ?
                    array_merge(array($v), $t) :
                    array($v, $t);
            }
        }
        return $result;
    }
}