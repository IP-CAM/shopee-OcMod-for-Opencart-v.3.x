<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedshopee
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ControllerExtensionModuleCedshopee extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/cedshopee');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('cedshopee', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] , true));
        }

        $data['url_live'] = 'https://partner.shopeemobile.com/api/v1/';

        $data['url_sandbox'] = 'https://partner.test.shopeemobile.com/api/v1/';

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['entry_api_url'] = $this->language->get('entry_api_url');
        $data['text_sandbox'] = $this->language->get('text_sandbox');
        $data['text_live'] = $this->language->get('text_live');
        $data['entry_partner_id'] = $this->language->get('entry_partner_id');
        $data['entry_shop_id'] = $this->language->get('entry_shop_id');
        $data['entry_shop_signature'] = $this->language->get('entry_shop_signature');

        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_debug'] = $this->language->get('entry_debug');
        $data['entry_order_email'] = $this->language->get('entry_order_email');
        $data['entry_auto_sync'] = $this->language->get('entry_auto_sync');
        $data['entry_update_all'] = $this->language->get('entry_update_all');
        $data['entry_update_price'] = $this->language->get('entry_update_price');
        $data['entry_update_inventry'] = $this->language->get('entry_update_inventry');
        $data['entry_inventry_choice'] = $this->language->get('entry_inventry_choice');
        $data['entry_price_choice'] = $this->language->get('entry_price_choice');
        $data['entry_variable_price'] = $this->language->get('entry_variable_price');
        $data['entry_validate'] = $this->language->get('entry_validate');
        $data['entry_auto_order'] = $this->language->get('entry_auto_order');
        $data['entry_order_shipped'] = $this->language->get('entry_order_shipped');

        $data['help_debug'] = $this->language->get('help_debug');
        $data['help_update_inventry'] = $this->language->get('help_update_inventry');
        $data['help_update_price'] = $this->language->get('help_update_price');
        $data['help_update_all'] = $this->language->get('help_update_all');
        $data['help_auto_sync'] = $this->language->get('help_auto_sync');
        $data['help_order_email'] = $this->language->get('help_order_email');

        $data['help_validate'] = $this->language->get('help_validate');
        $data['help_price_choice'] = $this->language->get('help_price_choice');
        $data['help_inventry_choice'] = $this->language->get('help_inventry_choice');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_validate'] = $this->language->get('button_validate');
        $data['button_cancel'] = $this->language->get('button_cancel');

        $data['tab_general'] = $this->language->get('tab_general');
        $data['tab_product'] = $this->language->get('tab_product');
        $data['tab_order'] = $this->language->get('tab_order');
        $data['tab_cron'] = $this->language->get('tab_cron');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['error_api_url'])) {
            $data['error_api_url'] = $this->error['error_api_url'];
        } else {
            $data['error_api_url'] = '';
        }

        if (isset($this->error['error_shop_id'])) {
            $data['error_shop_id'] = $this->error['error_shop_id'];
        } else {
            $data['error_shop_id'] = '';
        }
        if (isset($this->error['error_shop_signature'])) {
            $data['error_shop_signature'] = $this->error['error_shop_signature'];
        } else {
            $data['error_shop_signature'] = '';
        }

        if (isset($this->error['error_order_email'])) {
            $data['error_order_email'] = $this->error['error_order_email'];
        } else {
            $data['error_order_email'] = '';
        }

        if (isset($this->error['error_partner_id'])) {
            $data['error_partner_id'] = $this->error['error_partner_id'];
        } else {
            $data['error_partner_id'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/cedshopee', 'user_token=' . $this->session->data['user_token'], true)
        );
        $data['user_token']= $this->session->data['user_token'];
        $data['action'] = $this->url->link('extension/module/cedshopee', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        $data['help_tax_code_link'] = $this->url->link('cedshopee/category/tax', 'user_token=' . $this->session->data['user_token'], true);

        if (isset($this->request->post['cedshopee_api_url'])) {
            $data['cedshopee_api_url'] = $this->request->post['cedshopee_api_url'];
        } else if ($this->config->get('cedshopee_api_url')) {
            $data['cedshopee_api_url'] = $this->config->get('cedshopee_api_url');
        } else {
            $data['cedshopee_api_url'] = 'https://partner.test.shopeemobile.com/api/v1/';
        }

        if (isset($this->request->post['cedshopee_partner_id'])) {
            $data['cedshopee_partner_id'] = $this->request->post['cedshopee_partner_id'];
        } else if ($this->config->get('cedshopee_partner_id')) {
            $data['cedshopee_partner_id'] = $this->config->get('cedshopee_partner_id');
        } else {
            $data['cedshopee_partner_id'] = '';
        }

        if (isset($this->request->post['cedshopee_shop_id'])) {
            $data['cedshopee_shop_id'] = $this->request->post['cedshopee_shop_id'];
        } else if ($this->config->get('cedshopee_shop_id')) {
            $data['cedshopee_shop_id'] = $this->config->get('cedshopee_shop_id');
        } else {
            $data['cedshopee_shop_id'] = '';
        }

        if (isset($this->request->post['cedshopee_shop_signature'])) {
            $data['cedshopee_shop_signature'] = $this->request->post['cedshopee_shop_signature'];
        } else if ($this->config->get('cedshopee_shop_signature')) {
            $data['cedshopee_shop_signature'] = $this->config->get('cedshopee_shop_signature');
        } else {
            $data['cedshopee_shop_signature'] = '';
        }

        if (isset($this->request->post['cedshopee_debug'])) {
            $data['cedshopee_debug'] = $this->request->post['cedshopee_debug'];
        } else if ($this->config->get('cedshopee_debug')) {
            $data['cedshopee_debug'] = $this->config->get('cedshopee_debug');
        } else {
            $data['cedshopee_debug'] = '';
        }

        if (isset($this->request->post['cedshopee_order_email'])) {
            $data['cedshopee_order_email'] = $this->request->post['cedshopee_order_email'];
        } else if ($this->config->get('cedshopee_order_email')) {
            $data['cedshopee_order_email'] = $this->config->get('cedshopee_order_email');
        } else {
            $data['cedshopee_order_email'] = '';
        }

        if (isset($this->request->post['cedshopee_status'])) {
            $data['cedshopee_status'] = $this->request->post['cedshopee_status'];
        } else if ($this->config->get('cedshopee_status')) {
            $data['cedshopee_status'] = $this->config->get('cedshopee_status');
        } else {
            $data['cedshopee_status'] = '';
        }

        if (isset($this->request->post['cedshopee_auto_order'])) {
            $data['cedshopee_auto_order'] = $this->request->post['cedshopee_auto_order'];
        } else if ($this->config->get('cedshopee_auto_order')) {
            $data['cedshopee_auto_order'] = $this->config->get('cedshopee_auto_order');
        } else {
            $data['cedshopee_auto_order'] = '';
        }


        if (isset($this->request->post['cedshopee_auto_sync'])) {
            $data['cedshopee_auto_sync'] = $this->request->post['cedshopee_auto_sync'];
        } else if ($this->config->get('cedshopee_auto_sync')) {
            $data['cedshopee_auto_sync'] = $this->config->get('cedshopee_auto_sync');
        } else {
            $data['cedshopee_auto_sync'] = '';
        }

        if (isset($this->request->post['cedshopee_update_all'])) {
            $data['cedshopee_update_all'] = $this->request->post['cedshopee_update_all'];
        } else if ($this->config->get('cedshopee_update_all')) {
            $data['cedshopee_update_all'] = $this->config->get('cedshopee_update_all');
        } else {
            $data['cedshopee_update_all'] = '';
        }

        if (isset($this->request->post['cedshopee_update_price'])) {
            $data['cedshopee_update_price'] = $this->request->post['cedshopee_update_price'];
        } else if ($this->config->get('cedshopee_update_price')) {
            $data['cedshopee_update_price'] = $this->config->get('cedshopee_update_price');
        } else {
            $data['cedshopee_update_price'] = '';
        }

        if (isset($this->request->post['cedshopee_inventry_choice'])) {
            $data['cedshopee_inventry_choice'] = $this->request->post['cedshopee_inventry_choice'];
        } else if ($this->config->get('cedshopee_inventry_choice')) {
            $data['cedshopee_inventry_choice'] = $this->config->get('cedshopee_inventry_choice');
        } else {
            $data['cedshopee_inventry_choice'] = '';
        }

        if (isset($this->request->post['cedshopee_price_choice'])) {
            $data['cedshopee_price_choice'] = $this->request->post['cedshopee_price_choice'];
        } else if ($this->config->get('cedshopee_price_choice')) {
            $data['cedshopee_price_choice'] = $this->config->get('cedshopee_price_choice');
        } else {
            $data['cedshopee_price_choice'] = '';
        }
        if (isset($this->request->post['cedshopee_variable_price'])) {
            $data['cedshopee_variable_price'] = $this->request->post['cedshopee_variable_price'];
        } else if ($this->config->get('cedshopee_variable_price')) {
            $data['cedshopee_variable_price'] = $this->config->get('cedshopee_variable_price');
        } else {
            $data['cedshopee_variable_price'] = '';
        }
        $data['price_choices'] = array(
            '1'=>'Default Price',
            '2'=>'Increase By Fix Amount',
            '3'=>'Decrease By Fix Amount',
            '4'=>'Increase By Fix Percent',
            '5'=>'Decrease By Fix Percent',
            '6'=>'Price From Walmart Form Field'
        );
        $data['inventry_choice'] = array(
            '1'=>'Default Quantity',
            '2'=>'Quantity From Walmart Form Field'
        );

        if (isset($this->request->post['cedshopee_update_inventry'])) {
            $data['cedshopee_update_inventry'] = $this->request->post['cedshopee_update_inventry'];
        } else if ($this->config->get('cedshopee_update_inventry')) {
            $data['cedshopee_update_inventry'] = $this->config->get('cedshopee_update_inventry');
        } else {
            $data['cedshopee_update_inventry'] = '';
        }
        if (isset($this->request->post['cedshopee_validate_status'])) {
            $data['cedshopee_validate_status'] = $this->request->post['cedshopee_validate_status'];
        } else if ($this->config->get('cedshopee_validate_status')) {
            $data['cedshopee_validate_status'] = $this->config->get('cedshopee_validate_status');
        } else {
            $data['cedshopee_validate_status'] = '';
        }

        $cron_array = array(
            'Product Upload'=> HTTP_CATALOG.'index.php?route=cedshopee/product/updatestatus',
            'Sync Quantity'=> HTTP_CATALOG.'index.php?route=cedshopee/product/updateStock',
            'Sync Price'=> HTTP_CATALOG.'index.php?route=cedshopee/product/updatePrice',
            'Fetch Order'=> HTTP_CATALOG.'index.php?route=cedshopee/order/index');
        $data['crons'] = $cron_array;

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/module/cedshopee', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/cedshopee')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if ((utf8_strlen($this->request->post['cedshopee_api_url']) < 3) || (utf8_strlen($this->request->post['cedshopee_api_url']) > 64)) {
            $this->error['error_api_url'] = $this->language->get('error_api_url');
        }
        $pattern='/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';

        if (!preg_match($pattern, $this->request->post['cedshopee_order_email'])) {
            $this->error['error_order_email'] = $this->language->get('error_order_email');
        }

        if (!$this->request->post['cedshopee_partner_id']) {
            $this->error['error_partner_id'] = $this->language->get('error_partner_id');
        }

        if (!$this->request->post['cedshopee_shop_signature']) {
            $this->error['error_shop_signature'] = $this->language->get('error_shop_signature');
        }

        if (!$this->request->post['cedshopee_shop_id']) {
            $this->error['error_shop_id'] = $this->language->get('error_shop_id');
        }

        return !$this->error;
    }

    public function install() {

        $this->load->model('user/user_group');

         $this->load->model('setting/event');
        $this->model_setting_event->addEvent('add_shopee_menu', 'admin/view/common/column_left/before', 'cedshopee/column_left/eventMenu');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/category');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/attribute');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/attribute');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/product');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/order');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/profile');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/profile');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/option');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/option');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/logistics');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/logistics');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/return');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/return');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/discount');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/discount');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'cedshopee/column_left');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'cedshopee/column_left');

        $this->load->library('cedshopee');

        $cwal_lib = Cedshopee::getInstance($this->registry);

        if (!$cwal_lib->isCedshopeeInstalled()) {

            $cwal_lib->installCedshopee();

        }
    }

    public function uninstall() {
        $this->db->query("DELETE  FROM `".DB_PREFIX."setting` WHERE `key` LIKE '%cedshopee%'");
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('add_shopee_menu');
    }

    public function validateapi()
    {
        //die('ok');
        $this->load->library('cedshopee');
        $cedshopee = Cedshopee::getInstance($this->registry);
        $url ='shop/get';
        $params= array();
        $response = $cedshopee->postRequest($url, $params);

        $cedshopee->log('=====validate===',6,true);
        $cedshopee->log(json_encode($response),6,true);
        if(isset($response['error']) && $response['error']) {
            $response   =   $response['msg'];
            if($response) {
                $message= "Validation error : Please Check the above details";
                $json=array('success'=>false,'message'=>$message);
            }
        } else {
            $message= "Woah You are all set. Details Validated Successfully";
            $json=array('success'=>true,'message'=>$message);
        }
        $this->response->setOutput(json_encode($json));
    }
    public function validateresult()
    {
        $post = $this->request->post;
        if (isset($post['result']) && $post['result']) {
            $code='cedshopee';
            $key ='cedshopee_validate_status';
            $store_id= $this->config->get('config_store_id');
            $value = $post['result'];
            $if_exists=$this->db->query("SELECT * FROM `" . DB_PREFIX . "setting` WHERE `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "' AND store_id = '" . (int)$store_id . "'");
            if ($if_exists && $if_exists->num_rows) {
                $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($value) . "', serialized = '0'  WHERE `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "' AND store_id = '" . (int)$store_id . "'");
            } else {
                $this->db->query("INSERT INTO " . DB_PREFIX . "setting SET store_id = '" . (int)$store_id . "', `code` = '" . $this->db->escape($code) . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($value) . "'");
            }
            $message = $value ;
            $json=array('success'=>true,'message'=>$message);
            $this->response->setOutput(json_encode($json));
        } else {
            $message ='Error while saving settings';
            $json=array('success'=>false,'message'=>$message);
            $this->response->setOutput(json_encode($json));
        }
    }

}
