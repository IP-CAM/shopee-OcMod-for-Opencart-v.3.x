<?php

class ControllerCedshopeeCategory extends Controller
{
    private $error = array();

    public function index()
    {
        $this->language->load('cedshopee/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedshopee/category');

        $this->getList();
    }

    protected function getList()
    {
        if (isset($this->request->get['filter_category_name'])) {
            $filter_category_name = $this->request->get['filter_category_name'];
        } else {
            $filter_category_name = null;
        }

        if (isset($this->request->get['filter_category_id'])) {
            $filter_category_id = $this->request->get['filter_category_id'];
        } else {
            $filter_category_id = null;
        }

        if (isset($this->request->get['filter_parent_id'])) {
            $filter_parent_id = $this->request->get['filter_parent_id'];
        } else {
            $filter_parent_id = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'category_name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_parent_id'])) {
            $url .= '&filter_parent_id=' . $this->request->get['filter_parent_id'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['fetch'] = $this->url->link('cedshopee/category/fetch', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('cedshopee/category/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $data['categorys'] = array();

        $filter_data = array(
            'filter_category_name' => $filter_category_name,
            'filter_category_id' => $filter_category_id,
            'filter_parent_id' => $filter_parent_id,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );


        $category_total = $this->model_cedshopee_category->getTotalCategories($filter_data);

        $results = $this->model_cedshopee_category->getCategories($filter_data);

        foreach ($results as $result) {

            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('cedshopee/category/update', 'user_token=' . $this->session->data['user_token'] . '&category_id=' . $result['category_id'] . $url, 'SSL')
            );

            $data['categorys'][] = array(
                'id' => $result['id'],
                'category_id' => $result['category_id'],
                'category_name' => $result['category_name'],
                'parent_id' => $result['parent_id'],
                'selected' => isset($this->request->post['selected']) && in_array($result['category_id'], $this->request->post['selected']),
                'action' => $action
            );
        }

        $data['user_token'] = $this->session->data['user_token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_parent_id'])) {
            $url .= '&filter_parent_id=' . $this->request->get['filter_parent_id'];
        }


        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_category_name'] = $this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . '&sort=category_name' . $url, 'SSL');
        $data['sort_category_id'] = $this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . '&sort=category_id' . $url, 'SSL');
        $data['sort_parent_id'] = $this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . '&sort=parent_id' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_category_name'])) {
            $url .= '&filter_category_name=' . urlencode(html_entity_decode($this->request->get['filter_category_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category_id'])) {
            $url .= '&filter_category_id=' . urlencode(html_entity_decode($this->request->get['filter_category_id'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_parent_id'])) {
            $url .= '&filter_parent_id=' . $this->request->get['filter_parent_id'];
        }


        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $category_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($category_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($category_total - $this->config->get('config_limit_admin'))) ? $category_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $category_total, ceil($category_total / $this->config->get('config_limit_admin')));

        $data['filter_category_name'] = $filter_category_name;
        $data['filter_category_id'] = $filter_category_id;
        $data['filter_parent_id'] = $filter_parent_id;


        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('cedshopee/category_list', $data));
    }

    public function autocomplete()
    {
        $json = array();

        if (isset($this->request->get['filter_name'])) {
            $this->load->model('cedshopee/category');

            if (isset($this->request->get['filter_name'])) {
                $filter_name = $this->request->get['filter_name'];
            } else {
                $filter_name = '';
            }

            if (isset($this->request->get['limit'])) {
                $limit = $this->request->get['limit'];
            } else {
                $limit = 20;
            }

            $data = array(
                'filter_name' => $filter_name,
                'start' => 0,
                'limit' => $limit
            );

            $results = $this->model_cedshopee_category->getCategories($data);
            foreach ($results as $category) {
                $json[] = array(
                    'category_id' => $category['category_id'],
                    'name' => strip_tags(html_entity_decode($category['category_name'], ENT_QUOTES, 'UTF-8')),
                );
            }

        }
        $this->response->setOutput(json_encode($json));
    }

    public function attributesByCategory(){
        $category_id = isset($this->request->get['category_id'])?$this->request->get['category_id']:0;
        $profile_id = isset($this->request->get['profile_id'])?$this->request->get['profile_id']:0;
        $html ='No Attribute Found , Please checkCategory.';
        if ($category_id) {
            $this->load->model('cedshopee/category');
            $this->load->model('catalog/attribute');
            $this->load->model('cedshopee/option');
            $this->load->model('cedshopee/profile');
            $attributes_options = $this->model_cedshopee_category->getAttributes($category_id);
           
            $mapped_attributes_options = array();
            if($profile_id)
            $mapped_attributes_options = $this->model_cedshopee_profile->getMappedAttributes($profile_id);

            $results = $this->model_catalog_attribute->getAttributes();
            $store_options = $this->model_cedshopee_option->getStoreOptions();
            $options = $store_options['options'];
            $option_values = $store_options['option_values'];
            $attributes = $this->model_cedshopee_category->getAttributes($category_id);
            $html ='';
            $required = array();
            foreach ($attributes as $attribute) {
                $key = $attribute['attribute_id'];
                $html .= '<div class="form-group">';
                if(isset($attribute['is_mandatory']) && $attribute['is_mandatory']){
                    $required[] = $attribute['attribute_id'];
                    $html .= '<span class="required" style="color: red; font-weight:bold; ">*</span>';
                    $html .= '<div class="col-sm-6 required">';
                    $html .= '<input type="hidden" name="profile_attribute_mapping['.$key.'][is_mandatory]" value="1"/>';
                } else {
                    $html .= '<div class="col-sm-6">';
                    $html .= '<input type="hidden" name="profile_attribute_mapping['.$key.'][is_mandatory]" value="0"/>';
                }
                $html .= '<input type="hidden" name="profile_attribute_mapping['.$key.'][attribute_type]" value="'.$attribute['attribute_type'].'"/>';
                $html .= '<input type="hidden" name="profile_attribute_mapping['.$key.'][input_type]" value="'.$attribute['input_type'].'"/>';
                $html .= '<select name="profile_attribute_mapping['.$key.'][shopee_attribute]" class="form-control">';
                if(!$attribute['is_mandatory'])
                $html .= '<option value=""></option>';
                foreach ($attributes_options as $attribute_option) {
                    $store_selected_option = false;
                    $shoppee_selected_option = false;
                    $mapped_options = false;
                    if(isset($mapped_attributes_options[$attribute['attribute_id']]) && isset($mapped_attributes_options[$attribute['attribute_id']]['shopee_attribute']) && isset($mapped_attributes_options[$attribute['attribute_id']]['store_attribute'])) {

                        if($mapped_attributes_options[$attribute['attribute_id']]['store_attribute'])
                        $store_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['store_attribute'];

                        if(isset($mapped_attributes_options[$attribute['attribute_id']]['options'][$attribute['attribute_id']]) && $mapped_attributes_options[$attribute['attribute_id']]['options'][$attribute['attribute_id']])
                            $mapped_options = $mapped_attributes_options[$attribute['attribute_id']]['options'][$attribute['attribute_id']];

                        if($mapped_attributes_options[$attribute['attribute_id']]['shopee_attribute'])
                        $shoppee_selected_option = $mapped_attributes_options[$attribute['attribute_id']]['shopee_attribute'];
                    }
                    if($shoppee_selected_option && ($attribute_option['attribute_id']==$shoppee_selected_option)) {
                        $html .= '<option selected="selected" value="'.$attribute_option['attribute_id'].'">';
                        $html .= $attribute_option['attribute_name'];
                        $html .= '</option>';
                    } else if($attribute['is_mandatory'] && ($attribute_option['attribute_id']==$attribute['attribute_id'])){
                        $html .= '<option selected="selected" value="'.$attribute_option['attribute_id'].'">';
                        $html .= $attribute_option['attribute_name'];
                        $html .= '</option>';
                    } else {
                        $html .= '<option value="'.$attribute_option['attribute_id'].'">';
                        $html .= $attribute_option['attribute_name'];
                        $html .= '</option>';
                    }
                }
                $html .= '</select>';
                $html .= '</div>';
                $html .= '<div class="col-sm-6">';

                if (in_array($attribute['input_type'], array('DROP_DOWN', 'COMBO_BOX'))) {
                    $html .= '<select id="profile_attribute_mapping['.$key.'][store_attribute]" name="profile_attribute_mapping['.$key.'][store_attribute]" onchange="addOptionValues(this);" class="form-control">';

                    if(!$attribute['is_mandatory'])
                    $html .= '<option value=""></option>';
                    else
                        $html .= '<option value="No Brand">No Brand</option>';
                    foreach ($options as $option) {
                        if($store_selected_option && ($option['option_id']==$store_selected_option)) {
                            $html .= '<option selected="selected" value="'.$option['option_id'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option value="'.$option['option_id'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        }

                    }
                    $html .= '</select>';

                    $attribute['options'] = json_decode($attribute['options'], true);
                    $option_html = '';
                    $option_html .= '<a style="margin-left:1%;" class="center button" onclick="toggleOptions(' . $key . ')"> Map Option(s)</a>
                    <div style="display:none;" id="panel' . $key . '">';
                    //$option_html .= '<table class="list">';
                    foreach ($attribute['options'] as $index => $opt) {

                        $store_selected_option_values = false;
                        $shopee_selected_option_values = false;
                        if(isset($mapped_options[$index]) && isset($mapped_options[$index]['shopee_options']) && isset($mapped_options[$index]['store_options'])) {

                            if($mapped_options[$index]['shopee_options'])
                                $shopee_selected_option_values = $mapped_options[$index]['shopee_options'];

                            if($mapped_options[$index]['store_options'])
                                $store_selected_option_values = $mapped_options[$index]['store_options'];
                        }
                        $option_html .= '<div class="form-group">';
                        $option_html .= '<div class="col-sm-6">';
                        $option_html .= '<select name="profile_attribute_mapping[' . $key . '][options][' . $attribute['attribute_id'] . ']['.$index.'][shopee_options]" class="form-control">';
                        foreach ($attribute['options'] as $option) {
                            if($shopee_selected_option_values==$option)
                                $option_html .= '<option selected="selected" value="' . $option . '">';
                            else
                                $option_html .= '<option value="' . $option . '">';
                            $option_html .= $option;
                            $option_html .= '</option>';
                        }
                        $option_html .= '</select>';
                        $option_html .= '</div>';
                        $option_html .= '<div class="col-sm-6">';
                        $option_html .= '<select name="profile_attribute_mapping[' . $key . '][options][' . $attribute['attribute_id'] . ']['.$index.'][store_options]" class="form-control">';

                        if(isset($option_values[$store_selected_option]) && !empty($option_values[$store_selected_option])){
                            $option_html .= '<option value=""></option>';
                            //print_r($option_values[$store_selected_option]);
                           // echo $store_selected_option_values;
                            foreach ($option_values[$store_selected_option] as $option_value) {

                                if(trim($option_value['option_value_id'])==$store_selected_option_values)
                                    $option_html .= '<option selected="selected" value="' . $option_value['option_value_id'] . '">';
                                else
                                    $option_html .= '<option value="' .  $option_value['option_value_id'] . '">';
                                $option_html .=  $option_value['name'];
                                $option_html .= '</option>';
                            }
                        }
                        $option_html .= '</select>';
                        $option_html .= '</div>';
                        $option_html .= '</div>';
                    }
                    //$option_html .= '</table>';
                    $option_html .= '</div>';
                    $html .= $option_html;
                } else {
                    $html .= '<select name="profile_attribute_mapping['.$key.'][store_attribute]" class="form-control">';
                    if(!$attribute['is_mandatory'])
                        $html .= '<option value=""></option>';
                    else
                        $html .= '<option value="No Brand">No Brand</option>';
                    foreach ($results as $result) {
                        if($store_selected_option && ($result['attribute_id']==$store_selected_option)) {
                            $html .= '<option selected="selected" value="'.$result['attribute_id'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option value="'.$result['attribute_id'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        }
                    }
                    $html .= '</select>';
                }
                $html .= '</div>';
                $html .= '</div>';

            }
            $html .= "<input type=hidden id=store_options_json value='".json_encode($option_values)."' />";
            $this->response->setOutput($html);
        } else {
            $this->response->setOutput($html);
        }
    }

    public function fetch() {

        $this->language->load('cedshopee/category');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('cedshopee/category');
        $this->load->library('cedshopee');
        $cedshopee = Cedshopee::getInstance($this->registry);
        $response = $cedshopee->postRequest('item/categories/get', array());
// echo '<pre>'; print_r($response); die;
        if (!isset($response['error']) && isset($response['categories'])) {
            $this->session->data['success'] = $this->language->get('text_success');
            $this->model_cedshopee_category->addShopeeCategories($response['categories']);
        } else if (isset($response['msg'])) {
            $this->error['warning'] = $response['msg'];
        } else {
            $this->error['warning'] = 'No response from by shopee.com';
        }
        $this->getList();
    }
    public function delete() {
        $this->language->load('cedshopee/category');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedshopee/category');

        if (isset($this->request->post['selected']) && $this->validateDelete()) {
            foreach ($this->request->post['selected'] as $filter_group_id) {
                $this->model_cedshopee_category->deleteCategory($filter_group_id);
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('cedshopee/category', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
        }

        $this->getList();
    }
    protected function validateDelete() {
        if (!$this->user->hasPermission('modify', 'cedshopee/category')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }
}
?>