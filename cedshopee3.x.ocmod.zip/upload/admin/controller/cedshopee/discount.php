<?php

class ControllerCedshopeeDiscount extends Controller
{
    private $error = array();

    public function index() {
        $this->language->load('cedshopee/discount');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedshopee/discount');

        $this->getList();
    }

    public function insert() {
        $this->language->load('cedshopee/discount');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('cedshopee/discount');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
            //$data_to_insert = $this->request->post;
            $this->load->library('cedshopee');
            $cedshopee = Cedshopee::getInstance($this->registry);
            $this->request->post['start_time'] = strtotime($this->request->post['start_date']);
            unset($this->request->post['start_date']);
            $this->request->post['end_time'] = strtotime($this->request->post['end_date']);
            unset($this->request->post['end_date']);
            $this->request->post['items'] = $this->request->post['shopee_items'];
            unset($this->request->post['shopee_items']);
            unset($this->request->post['items']);
            unset($this->request->post['product']);
            unset($this->request->post['product_id']);

            $response = $cedshopee->postRequest('discount/add', $this->request->post);

            if (!isset($response['error']) && isset($response['discount_id'])) {
                // echo '<pre>'; print_r($data_to_insert); die;
                $this->request->post['discount_id'] = $response['discount_id'];
                $this->model_cedshopee_discount->addDiscount($this->request->post);
                $this->session->data['success'] = $this->language->get('text_success');
            } else {
                $this->error['warning'] = $response['msg'];
                $this->getForm();
                return;
            }

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
        }

        $this->getForm();
    }

    public function update() {
        $this->language->load('cedshopee/discount');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedshopee/discount');
// echo '<pre>'; print_r($this->request->post); die;
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
            $this->load->library('cedshopee');
            $cedshopee = Cedshopee::getInstance($this->registry);
            $this->request->post['start_time'] = strtotime($this->request->post['start_date']);
            $this->request->post['end_time'] = strtotime($this->request->post['end_date']);
            $this->request->post['discount_id'] = (int)$this->request->post['discount_id'];
            $discount_data = $this->request->post;
            $discount_data['items'] = array();
            foreach ($discount_data['shopee_item'] as $shopee_item) {
                $discount_data['items'][] = array('item_id' => (int)$shopee_item, 'item_promotion_price' => 90, 'purchase_limit' => 90);
            }
            $response = $cedshopee->postRequest('discount/update', $discount_data );

            if (!isset($response['error']) && isset($response['discount_id'])) {
                $this->request->post['discount_id'] = $response['discount_id'];
                $this->model_cedshopee_discount->editDiscount($this->request->post['discount_id'], $this->request->post);
                $this->session->data['success'] = $this->language->get('text_success');
            } else {
                $this->error['warning'] = $response['msg'];
                $this->getForm();
                return;
            }
            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
        }

        $this->getForm();
    }

    public function delete() {
        $this->language->load('cedshopee/discount');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('cedshopee/discount');
        if (isset($this->request->post['selected']) && $this->validateDelete()) {
            $this->load->library('cedshopee');
            $cedshopee = Cedshopee::getInstance($this->registry);
            foreach ($this->request->post['selected'] as $discount_id) {
                $response = $cedshopee->postRequest('discount/update', array('discount_id'=> (int)$discount_id));
                if (isset($response['discount_id']) && $response['discount_id']) {
                    $this->request->post['discount_id'] = $response['discount_id'];
                    $this->model_cedshopee_discount->deleteDiscountByDiscountId($this->request->post['discount_id'], $this->request->post);
                    $this->session->data['success'] = $this->language->get('text_success');
                } else {
                    $this->error['warning'] = $response['msg'];
                }
            }

            $this->session->data['success'] = $this->language->get('text_success');

            $url = '';

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $this->response->redirect($this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL'));
        }

        $this->getList();
    }

    protected function getList() {
        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'r.date_added';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('heading_title'),
            'href'      => $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        $data['insert'] = $this->url->link('cedshopee/discount/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        $data['delete'] = $this->url->link('cedshopee/discount/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        $data['discounts'] = array();

        $filter_data = array(
            'sort'  => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );

        $discount_total = $this->model_cedshopee_discount->getTotalDiscounts();

        $results = $this->model_cedshopee_discount->getDiscounts($filter_data);

        foreach ($results as $result) {
            $action = array();

            $action[] = array(
                'text' => $this->language->get('text_edit'),
                'href' => $this->url->link('cedshopee/discount/update', 'user_token=' . $this->session->data['user_token'] . '&id=' . $result['id'] . $url, 'SSL')
            );

            $data['discounts'][] = array(
                'id'  => $result['id'],
                'discount_id'  => $result['discount_id'],
                'discount_name'       => $result['discount_name'],
                'end_date' => date($this->language->get('date_format_short'), strtotime($result['end_date'])),
                'start_date' => date($this->language->get('date_format_short'), strtotime($result['start_date'])),
                'selected'   => isset($this->request->post['selected']) && in_array($result['id'], $this->request->post['selected']),
                'action'     => $action
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_list'] = $this->language->get('text_list');

        $data['text_no_results'] = $this->language->get('text_no_results');

        $data['column_discount_id'] = $this->language->get('column_discount_id');
        $data['column_discount_name'] = $this->language->get('column_discount_name');
        $data['column_start_date'] = $this->language->get('column_start_date');
        $data['column_end_date'] = $this->language->get('column_end_date');
        $data['column_action'] = $this->language->get('column_action');

        $data['button_insert'] = $this->language->get('button_insert');
        $data['button_delete'] = $this->language->get('button_delete');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_product'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . '&sort=pd.name' . $url, 'SSL');
        $data['sort_author'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . '&sort=r.author' . $url, 'SSL');
        $data['sort_rating'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . '&sort=r.rating' . $url, 'SSL');
        $data['sort_status'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . '&sort=r.status' . $url, 'SSL');
        $data['sort_date_added'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . '&sort=r.date_added' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $discount_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($discount_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($discount_total - $this->config->get('config_limit_admin'))) ? $discount_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $discount_total, ceil($discount_total / $this->config->get('config_limit_admin')));

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('cedshopee/discount_list', $data));
    }

    protected function getForm() {
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_none'] = $this->language->get('text_none');
        $data['text_select'] = $this->language->get('text_select');

        $data['entry_items'] = $this->language->get('entry_items');
        $data['entry_discount_name'] = $this->language->get('entry_discount_name');
        $data['entry_rating'] = $this->language->get('entry_rating');
        $data['entry_start_date'] = $this->language->get('entry_start_date');
        $data['entry_end_date'] = $this->language->get('entry_end_date');


        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['items'])) {
            $data['error_items'] = $this->error['items'];
        } else {
            $data['error_items'] = '';
        }

        if (isset($this->error['discount_name'])) {
            $data['error_discount_name'] = $this->error['discount_name'];
        } else {
            $data['error_discount_name'] = '';
        }

        if (isset($this->error['start_date'])) {
            $data['error_start_date'] = $this->error['start_date'];
        } else {
            $data['error_start_date'] = '';
        }

        if (isset($this->error['end_date'])) {
            $data['error_end_date'] = $this->error['end_date'];
        } else {
            $data['error_end_date'] = '';
        }

        $url = '';

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('heading_title'),
            'href'      => $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL')
        );

        if (!isset($this->request->get['id'])) {
            $data['action'] = $this->url->link('cedshopee/discount/insert', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');
        } else {
            $data['action'] = $this->url->link('cedshopee/discount/update', 'user_token=' . $this->session->data['user_token'] . '&id=' . $this->request->get['id'] . $url, 'SSL');
        }

        $data['cancel'] = $this->url->link('cedshopee/discount', 'user_token=' . $this->session->data['user_token'] . $url, 'SSL');

        if (isset($this->request->get['id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
            $discount_info = $this->model_cedshopee_discount->getDiscount($this->request->get['id']);
        }

        $data['user_token'] = $this->session->data['user_token'];

        $this->load->model('catalog/product');

        if (isset($this->request->post['discount_id'])) {
            $data['discount_id'] = $this->request->post['discount_id'];
        } elseif (!empty($discount_info)) {
            $data['discount_id'] = $discount_info['discount_id'];
        } else {
            $data['discount_id'] = '';
        }
        $data['shopee_items'] = array();
        if (isset($this->request->post['shopee_item'])) {
            foreach ($this->request->post['shopee_item'] as $shop_item) {
                $results =  $this->db->query("SELECT pd.name, cpp.shopee_item_id FROM `".DB_PREFIX."cedshopee_profile_products` cpp LEFT JOIN `".DB_PREFIX."product_description` pd ON (cpp.product_id=pd.product_id) where cpp.shopee_item_id = '".$shop_item."'");
                if(!empty($results->row))
                $data['shopee_items'][]= $results->row;
            }
        } elseif (!empty($discount_info)) {
            $shop_items = (json_decode($discount_info['items'],true))?json_decode($discount_info['items'],true):array();
            foreach ($shop_items as $shop_item) {
               $results =  $this->db->query("SELECT pd.name, cpp.shopee_item_id FROM `".DB_PREFIX."cedshopee_profile_products` cpp LEFT JOIN `".DB_PREFIX."product_description` pd ON (cpp.product_id=pd.product_id) where cpp.shopee_item_id = '".$shop_item."'");
                $data['shopee_items'][]= $results->row;
            }
        } else {
            $data['shopee_items'] = array();
        }

        if (isset($this->request->post['discount_name'])) {
            $data['discount_name'] = $this->request->post['discount_name'];
        } elseif (!empty($discount_info)) {
            $data['discount_name'] = $discount_info['discount_name'];
        } else {
            $data['discount_name'] = '';
        }


        if (isset($this->request->post['start_date'])) {
            $data['start_date'] = $this->request->post['start_date'];
        } elseif (!empty($discount_info)) {
            $data['start_date'] = $discount_info['start_date'];
        } else {
            $data['start_date'] = '';
        }

        if (isset($this->request->post['end_date'])) {
            $data['end_date'] = $this->request->post['end_date'];
        } elseif (!empty($discount_info)) {
            $data['end_date'] = $discount_info['end_date'];
        } else {
            $data['end_date'] = '';
        }

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('cedshopee/discount_form', $data));
    }

    protected function validateForm() {
        if (!$this->user->hasPermission('modify', 'cedshopee/discount')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['discount_name']) {
            $this->error['discount_name'] = $this->language->get('error_discount_name');
        }

        if ((utf8_strlen($this->request->post['discount_name']) < 3) || (utf8_strlen($this->request->post['discount_name']) > 64)) {
            $this->error['discount_name'] = $this->language->get('error_discount_name');
        }

       if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    protected function validateDelete() {
        if (!$this->user->hasPermission('modify', 'cedshopee/discount')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }
}

?>