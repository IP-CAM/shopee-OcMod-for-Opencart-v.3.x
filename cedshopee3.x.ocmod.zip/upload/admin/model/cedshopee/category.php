<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedshopee
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ModelCedshopeeCategory extends Model {

	public function getCategories($data = array()) {

		$sql = "SELECT * FROM " . DB_PREFIX . "cedshopee_category where category_id >0 ";

		if (!empty($data['filter_category_name'])) {
			$sql .= " AND category_name LIKE '%" . strip_tags(html_entity_decode($this->db->escape($data['filter_category_name']), ENT_QUOTES, 'UTF-8')) . "%'";
		}

		if (!empty($data['filter_category_id'])) {
			$sql .= " AND category_id = '" . $this->db->escape($data['filter_category_id']) . "%'";
		}

		if (!empty($data['filter_parent_id'])) {
			$sql .= " AND parent_id LIKE '" . $this->db->escape($data['filter_parent_id']) . "%'";
		}

		$sql .= " GROUP BY category_id";

        $sort_data = array(
            'category_name',
            'category_id',
            'parent_id'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY category_name";
        }

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
       // echo '<pre>'; print_r($sql); die;
		$query = $this->db->query($sql);

		return $query->rows;
	}
	public function deleteCategory($category_id) {
		$this->db->query("DELETE FROM `".DB_PREFIX."cedshopee_category` where id='".$category_id."'");
	}

	public function getTotalCategories($data = array())
	{
		$sql = "SELECT count(category_id) AS total FROM " . DB_PREFIX . "cedshopee_category where category_id > '0' ";

		if (!empty($data['filter_category_name'])) {
			$sql .= " AND category_name LIKE '" . $this->db->escape($data['filter_category_name']) . "%'";
		}

		if (!empty($data['filter_category_id'])) {
			$sql .= " AND category_id = '" . $this->db->escape($data['filter_category_id']) . "%'";
		}

        if (!empty($data['filter_parent_id'])) {
            $sql .= " AND parent_id LIKE '" . $this->db->escape($data['filter_parent_id']) . "%'";
        }

		$query = $this->db->query($sql);

		return $query->row['total'];
	}

	public function getAttributes($category_id) {
		if ($category_id) {
			$results = $this->db->query("SELECT * FROM `".DB_PREFIX."cedshopee_attribute` where category_id='".$category_id."'");
			if ($results && $results->num_rows) {
				return $results->rows;
			} else {
				$this->load->model('cedshopee/logistics');
				$this->load->library('cedshopee');
				$cedshopee = Cedshopee::getInstance($this->registry);
				$response = $cedshopee->postRequest('item/attributes/get', array('category_id' => (int)$category_id));
				if (!isset($response['error']) && isset($response['attributes'])) {
					$this->model_cedshopee_category->addAttributes($category_id, $response['attributes']);
					return $response['attributes'];
				} else {
					return array();
				}
			}
		} else {
			return array();
		}
	}
	public function getAttributeOptions($category_id) {
		if ($category_id) {
			$results = $this->db->query("SELECT `attribute_id`,`attribute_name`,`options`, `is_mandatory` FROM `".DB_PREFIX."cedshopee_attribute` where category_id='".$category_id."'");
			if ($results && $results->num_rows) {
				return $results->rows;
			}
		} else {
			return array();
		}
	}
	public function addShopeeCategories($data) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedshopee_category");
		foreach ($data as $category) {
		    // strip_tags(html_entity_decode($category['category_name'], ENT_QUOTES, 'UTF-8'))
			$this->db->query("INSERT INTO " . DB_PREFIX . "cedshopee_category SET category_id = '" . (int)$category['category_id'] . "', parent_id = '" . (int)$category['parent_id'] . "', has_children = '" . (int)$category['has_children'] . "', category_name = '" . strip_tags(html_entity_decode($this->db->escape($category['category_name']), ENT_QUOTES, 'UTF-8')) . "'");
		}
	}
	public function addAttributes($category_id, $data) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedshopee_attribute WHERE category_id = '" . (int)$category_id . "'");
		foreach ($data as $attribute) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "cedshopee_attribute SET attribute_id = '" . (int)$attribute['attribute_id'] . "', category_id = '" . (int)$category_id . "', is_mandatory = '" . (int)$attribute['is_mandatory'] . "', attribute_name = '" . strip_tags(html_entity_decode($this->db->escape($attribute['attribute_name']), ENT_QUOTES, 'UTF-8')) . "', attribute_type = '" . $this->db->escape($attribute['attribute_type']) . "', input_type = '" . $this->db->escape($attribute['input_type']) . "', options = '" . $this->db->escape(json_encode($attribute['options'])) . "'");
		}
	}
    public function getCategory() {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedshopee_category ORDER BY category_name");

        return $query->rows;
    }
}