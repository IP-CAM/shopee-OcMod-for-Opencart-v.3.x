<?php
class ModelCedshopeeProfile extends Model {
	public function addProfile($data) {
//		echo '<pre>'; print_r($data); die;

		$this->db->query("INSERT INTO " . DB_PREFIX . "cedshopee_profile SET title = '" . $data['title'] . "',
		   status = '" .(int)$data['status']  . "',
		  product_manufacturer = '" . $this->db->escape(json_encode($data['product_manufacturer'])) . "',
		   store_category = '" . $this->db->escape(json_encode($data['product_category'])) . "',
			shopee_category = '" . $this->db->escape($data['shopee_category_id']) . "',  
			shopee_category_name = '" . $this->db->escape($data['shopee_category']) . "',
			shopee_categories = '" . $this->db->escape(json_encode($data['shopee_category_id'])) . "',
			profile_store = '" . $this->db->escape(json_encode($data['profile_store'])) . "',
			default_mapping = '" . $this->db->escape(json_encode($data['default_mapping'])) . "',
			profile_attribute_mapping = '" . $this->db->escape(json_encode($data['profile_attribute_mapping'])) . "',
			
			logistics = '" . $this->db->escape(json_encode($data['logistics'])) . "',
			wholesale = '" . $this->db->escape(json_encode($data['wholesale'])) . "',
			profile_language = '" . $this->db->escape($data['profile_language']) . "'");
		$profile_id = $this->db->getLastId();
		if($profile_id){
			$this->removeProductFromProfile($profile_id);
			$this->addProductInProfile($profile_id, $data['product_category'], $data['profile_store'], $data['product_manufacturer']);	
		}
		
		$this->cache->delete('profile');
	}

	public function editProfile($profile_id, $data) {
//        echo '<pre>'; print_r($data); die;
		$this->db->query("UPDATE " . DB_PREFIX . "cedshopee_profile SET title = '" . $data['title'] . "',
		 status = '" .(int)$data['status']  . "', 
		 product_manufacturer = '" . $this->db->escape(json_encode($data['product_manufacturer'])) . "', 
		 store_category = '" . $this->db->escape(json_encode($data['product_category'])) . "',
			shopee_categories = '" . $this->db->escape(json_encode($data['shopee_category_id'])) . "',
			shopee_category = '" . $this->db->escape($data['shopee_category_id']) . "',  
			shopee_category_name = '" . $this->db->escape($data['shopee_category']) . "',
			profile_store = '" . $this->db->escape(json_encode($data['profile_store'])) . "',
			default_mapping = '" . $this->db->escape(json_encode($data['default_mapping'])) . "',
			profile_attribute_mapping = '" . $this->db->escape(json_encode($data['profile_attribute_mapping'])) . "',
			logistics = '" . $this->db->escape(json_encode($data['logistics'])) . "',
			wholesale = '" . $this->db->escape(json_encode($data['wholesale'])) . "',
			profile_language = '" . $this->db->escape($data['profile_language']) . "'  WHERE id = '" . (int)$profile_id . "'");

		$this->removeProductFromProfile($profile_id);
		$this->addProductInProfile($profile_id, $data['product_category'], $data['profile_store'], $data['product_manufacturer']);
		$this->cache->delete('profile');
	}

	public function deleteProfile($profile_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedshopee_profile WHERE id = '" . (int)$profile_id . "'");
		
		$this->cache->delete('profile');
	}	

	public function getProfile($profile_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedshopee_profile WHERE id = '" . (int)$profile_id . "'");

		return $query->row;
	}

	public function getProfiles($data = array()) {

			$sql = "SELECT * FROM " . DB_PREFIX . "cedshopee_profile cp WHERE id >= '0'";

			$sort_data = array(
				'title',
				'status',
				'id'
			);		

			if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
				$sql .= " ORDER BY " . $data['sort'];	
			} else {
				$sql .= " ORDER BY cp.title";	
			}

			if (isset($data['order']) && ($data['order'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}

			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}		

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}	

				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}	

			$query = $this->db->query($sql);

			return $query->rows;

	}

	public function getTotalProfiles() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "cedshopee_profile");

		return $query->row['total'];
	}	
	
	public function getDefaultAttributesMapping()
	{
		return array(
			'name' 			=> 'name',
			'description' 	=> 'description',
			'price' 		=> 'price',
			'stock' 		=> 'quantity',
			'item_sku' 		=> 'sku',
			'weight' 		=> 'weight',
			'package_length'=> 'length',
			'package_width' => 'width',
			'package_height'=> 'height',
			'days_to_ship' 	=> '',
		);
	}	
	public function getDefaultAttributes()
	{
		return array(
			'name' 			=> 'Name',
			'description' 	=> 'Description',
			'price' 		=> 'Price',
			'quantity' 		=> 'Quantity',
			'sku' 			=> 'SKU',
			'weight' 		=> 'Weight',
			'length'		=> 'Length',
			'width' 		=> 'Width',
			'height'		=> 'Height',
			'days_to_ship' 	=> '',
		);
	}	
	public function addProductInProfile($profile_id, $categories, $store, $manufacturer)
	{
		$sql = "SELECT DISTINCT (p.product_id) FROM `".DB_PREFIX."product` p LEFT JOIN `".DB_PREFIX."product_to_store` pts on (pts.product_id = p.product_id) LEFT JOIN `".DB_PREFIX."product_to_category` ptc on (ptc.product_id = p.product_id) where p.quantity >0 ";

		if(!empty($categories)){
			$sql .= "AND ptc.category_id IN(".implode(',', $categories).") ";
		}

		if(!empty($store)){
			$sql .= "AND pts.store_id IN(".implode(',', $store).") ";
		}

		if(!empty($manufacturer)){
			$sql .= "AND p.manufacturer_id IN(".implode(',', $manufacturer).") ";
		}
		
		$result = $this->db->query( $sql);

		if($result && $result->num_rows) {
			
			$products =  array_chunk( $result->rows, 1000);
			foreach ($products as $key => $value) {
				$sql = "INSERT INTO `".DB_PREFIX."cedshopee_profile_products` (`product_id`,`shopee_profile_id`) values ";
				foreach ( $result->rows as $key => $product) {
					$sql .= "('".$product['product_id']."','".$profile_id."'), ";
				}
				$sql = rtrim($sql, ', ');
				$this->db->query($sql);		
			}	
		}
	}
	public function removeProductFromProfile($profile_id)
	{
		$this->db->query("UPDATE `".DB_PREFIX."cedshopee_profile_products` SET shopee_profile_id='0' where `shopee_profile_id`='".$profile_id."'");
	}
	public function getMappedAttributes($profile_id) {
		$query = $this->db->query("SELECT `profile_attribute_mapping` FROM " . DB_PREFIX . "cedshopee_profile WHERE id = '" . (int)$profile_id . "'");
		if($query->num_rows){
			return json_decode($query->row['profile_attribute_mapping'], true);
		}
	}
}
?>
