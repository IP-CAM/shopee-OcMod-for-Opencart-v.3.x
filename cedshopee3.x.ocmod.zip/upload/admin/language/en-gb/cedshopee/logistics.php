<?php
// Heading
$_['heading_title']          	= 'Logistics';

// Text
$_['text_success']           	= 'Success: You have modified Logistics!';
$_['text_list']                 = 'Shopee Logistics';

// Column
$_['button_insert']            	= 'Fetch Logistics';
$_['column_name']            	= 'Logistics Name';
$_['column_logistics_id'] 	 	= 'Logistics ID';
$_['column_status']     	 	= 'Status';


// Entry
$_['entry_name']            	= 'Logistics Name';
$_['entry_id'] 					= 'Logistics ID';
$_['entry_status']      		= 'Status';

// Error
$_['error_permission']      	= 'Warning: You do not have permission to modify Logistics!';
?>