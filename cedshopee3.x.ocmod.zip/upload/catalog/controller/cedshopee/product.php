<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category  modules
 * @package   cedshopee
 * @author    CedCommerce Core Team
 * @copyright Copyright CEDCOMMERCE (http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 */
class ControllerCedshopeeProduct extends Controller
{
    public function updateStock()
    {
        $this->load->model('cedshopee/product');
        $post_data = $this->model_cedshopee_product->getAllShopeeProductIds();
        if (is_array($post_data) && !empty($post_data)) {
            $product_ids = $post_data;
            if (is_array($product_ids) && count($product_ids)) {
                foreach ($product_ids as $product_id) {
                    $this->model_cedshopee_product->updateInvenetry($product_id, array());
                }
            }
        }
    }
    
    public function updatePrice()
    {
        $this->load->model('cedshopee/product');
        $post_data = $this->model_cedshopee_product->getAllShopeeProductIds();
        if (is_array($post_data) && !empty($post_data)) {
            $product_ids = $post_data;
            if (is_array($product_ids) && count($product_ids)) {
                foreach ($product_ids as $product_id) {
                    $this->model_cedshopee_product->updatePrice($product_id, array());
                }
            }
        }
    }

    public function updatestatus()
    {
        $this->load->library('cedshopee');
        $cedshopee = Cedshopee::getInstance($this->registry);
        $pagination_offset = isset($this->request->post['pagination_offset']) ? $this->request->post['pagination_offset'] : 0;
        $pagination_entries_per_page = isset($this->request->post['pagination_entries_per_page']) ? $this->request->post['pagination_entries_per_page'] : 100;
        $response = $cedshopee->postRequest('items/get', array('pagination_offset' => (int)$pagination_offset, 'pagination_entries_per_page' => (int)$pagination_entries_per_page));
        if (!isset($response['error']) && isset($response['items']) && !empty($response['items'])) {
            foreach ($response['items'] as $items) {
                $sql = "UPDATE`" . DB_PREFIX . "cedshopee_profile_products` SET shopee_status='" . $items['status'] . "' where `shopee_item_id`='" . $items['item_id'] . "'";
                $this->db->query($sql);
            }
            if(isset($response['more']) && $response['more']) {
                $this->response->setOutput(json_encode(array('success' => true, 'pagination_offset' => (int)$pagination_entries_per_page, 'pagination_entries_per_page' =>(int) $pagination_entries_per_page )));
            } else {
                $this->response->setOutput(json_encode(array('success' => true, 'message' => 'Status Updated Successfully.')));
            }
        } else {
            if (isset($response['msg']))
                $this->response->setOutput(json_encode(array('success' => false, 'message' => $response['msg'])));
            else
                $this->response->setOutput(json_encode(array('success' => false, 'message' => ' No Response Found in store.')));
        }
    }
}